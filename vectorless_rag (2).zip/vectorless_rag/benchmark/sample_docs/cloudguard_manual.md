# CloudGuard Platform — Administrator & Security Manual

## 1. Overview

CloudGuard is a managed application security platform used by enterprise
customers to protect internet-facing web applications and APIs. This manual
covers installation, authentication, encryption, backup and disaster
recovery, monitoring, compliance, and troubleshooting for CloudGuard
version 4.2.

CloudGuard consists of three components: the Edge Proxy, the Control
Plane, and the Analytics Pipeline. The Edge Proxy terminates inbound
traffic and applies security rules. The Control Plane stores
configuration and policy state. The Analytics Pipeline processes traffic
logs for threat detection and reporting.



## 2. Installation and Deployment

### 2.1 System Requirements

The Control Plane requires a minimum of 8 vCPUs, 32 GB RAM, and 200 GB of
SSD storage. The Edge Proxy requires a minimum of 4 vCPUs and 8 GB RAM per
instance, and is designed to run as a horizontally scaled fleet.

### 2.2 Network Ports

For an on-premises deployment, the following ports must be open between
components: port 443 for HTTPS management traffic, port 8443 for the
internal Control Plane API, and port 5432 for PostgreSQL replication
between Control Plane nodes. Port 9090 is used for Prometheus metrics
scraping and should only be exposed on the internal management network.

### 2.3 Initial Setup

After installation, run `cloudguard-admin bootstrap` to initialize the
Control Plane database and generate the root administrator credentials.
The bootstrap process takes approximately 10 minutes to complete on
recommended hardware.



## 3. Authentication and Access Control

### 3.1 Single Sign-On (SSO)

CloudGuard supports SAML 2.0 and OIDC for single sign-on integration with
identity providers such as Okta, Azure AD, and Google Workspace. When SSO
is enabled, local password authentication is disabled for all users
except the emergency break-glass administrator account.

### 3.2 Password Policy

For accounts not using SSO, passwords must be a minimum of 12 characters
and include at least one uppercase letter, one number, and one special
character. Passwords expire every 90 days and cannot be reused for the
previous 5 password changes. Accounts are locked for 30 minutes after 5
consecutive failed login attempts.

### 3.3 API Keys and Tokens

API keys are used for programmatic access to the CloudGuard REST API. API
keys do not expire by default but can be configured with a maximum
lifetime by an administrator. When a maximum lifetime is configured, the
default and recommended value is 90 days, after which the key must be
rotated. Revoked API keys are rejected within 60 seconds across all Edge
Proxy nodes.

### 3.4 Session Management

Web console sessions time out after 15 minutes of user inactivity, after
which the user must re-authenticate. This is separate from the
Control Plane's configuration snapshot interval (see Section 5.2), which
also defaults to 15 minutes but controls how often configuration state is
persisted to disk, not user sessions.



## 4. Data Encryption and Key Management

### 4.1 Encryption at Rest

All customer configuration data and traffic logs stored by the Control
Plane and Analytics Pipeline are encrypted at rest using AES-256-GCM.
Encryption keys are managed through the built-in Key Management Service
(KMS) or an external KMS such as AWS KMS or HashiCorp Vault.

### 4.2 Encryption in Transit

All traffic between the Edge Proxy, Control Plane, and Analytics Pipeline
is encrypted in transit using TLS 1.3. TLS 1.0 and 1.1 are disabled by
default and cannot be re-enabled for inter-component traffic.

### 4.3 Key Rotation

Data encryption keys are rotated automatically every 180 days by the
built-in KMS. Manual key rotation can be triggered at any time by an
administrator with the `keys:rotate` permission, and takes effect within
5 minutes across the fleet.



## 5. Backup and Disaster Recovery

### 5.1 Backup Schedule

Full backups of the Control Plane database are taken every 6 hours and
retained for 30 days. Incremental backups are taken every 30 minutes and
retained for 7 days. Backups are stored in a separate storage account
from the primary deployment region.

### 5.2 Configuration Snapshots

In addition to database backups, the Control Plane persists a
configuration snapshot to local disk every 15 minutes. This snapshot is
used for fast local recovery in the event of a process crash and is not a
substitute for the full backup schedule described in Section 5.1.

### 5.3 Disaster Recovery Objectives

CloudGuard's disaster recovery plan targets a Recovery Time Objective
(RTO) of 4 hours and a Recovery Point Objective (RPO) of 15 minutes for a
full regional failover. Failover drills are conducted quarterly, and
results are documented in the customer-facing status report.



## 6. Monitoring, Alerting, and Rate Limits

### 6.1 Metrics and Dashboards

CloudGuard exposes Prometheus-compatible metrics on port 9090 for request
volume, latency, error rates, and blocked-attack counts. A pre-built
Grafana dashboard is available in the customer portal.

### 6.2 Alerting

Default alert rules notify administrators when error rates exceed 5% over
a 5-minute window, or when Edge Proxy CPU utilization exceeds 85% for
more than 10 minutes. Alerts are delivered via email, Slack, or PagerDuty.

### 6.3 API Rate Limits

The public management REST API is rate-limited to 1000 requests per
minute per API key for read operations, and 100 requests per minute per
API key for write operations. Exceeding the limit returns an HTTP 429
response with a `Retry-After` header. The maximum request body size for
API calls, including file uploads through the API, is 5 GB.



## 7. Compliance and Certifications

CloudGuard holds SOC 2 Type II certification, renewed annually, and ISO
27001 certification. CloudGuard is also HIPAA-eligible when deployed
under a signed Business Associate Agreement (BAA). Audit logs of all
administrative actions are retained for 90 days by default and can be
configured to export to an external SIEM for longer retention.

### 7.1 Data Residency

Customers on the Enterprise plan may pin their data to a specific region
(US, EU, or APAC) to satisfy data residency requirements. Data residency
changes require a support ticket and typically take 5 business days to
complete.



## 8. Trial Accounts and Licensing

New CloudGuard trial accounts are active for 14 days from creation and
include full access to all Enterprise-tier features except SSO
integration. Trial accounts are automatically downgraded to a read-only
state at the end of the trial period unless converted to a paid plan.
Paid plan invoices are issued monthly with net-30 payment terms.



## 9. Troubleshooting

### 9.1 Edge Proxy Not Receiving Traffic

Verify that port 443 is open and that the Edge Proxy's health check
endpoint returns HTTP 200. Check that the upstream load balancer's health
check interval is no longer than 30 seconds, since the Edge Proxy is
marked unhealthy after 3 consecutive failed health checks.

### 9.2 Control Plane Database Connection Errors

Confirm that port 5432 is reachable between Control Plane nodes and that
the PostgreSQL replication user's password has not expired under the
password policy described in Section 3.2. Connection pool exhaustion
errors typically resolve by increasing `max_connections` and restarting
the Control Plane service.

### 9.3 Delayed Analytics Data

Analytics Pipeline processing lag under 10 minutes is considered normal
during peak traffic. Lag exceeding 60 minutes should be reported to
support with the deployment ID and affected time range.
