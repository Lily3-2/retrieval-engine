# Sample Queries: Job Description Compendium

20 ground-truth questions used to evaluate retrieval against `job_description_compendium.pdf` (185 pages, ~150 job-description templates across 10 departments). Each entry lists the question, the page that actually contains the answer, and the keyword(s) a correct answer should contain.

| # | Question | Expected page | Expected keyword(s) | Distractor cluster |
|---|---|---|---|---|
| 1 | What are the requirements to become an Accounting Clerk? | 16 | aptitude for numbers | Accounting Manager (p17), Accounts Payable Clerk (p18), and Accounts Receivable Clerk (p19) sit on immediately adjacent pages with very similar wording ('accounting', 'clerk', 'BS degree', 'MS Office' all recur). |
| 2 | What does an Accounts Payable Clerk do on a daily basis? | 18 | payment cycle | Yes |
| 3 | What are an Accounts Receivable Clerk's main responsibilities? | 19 | bill reminders | Yes |
| 4 | What does an Accounting Manager oversee? | 17 | annual audits | Yes |
| 5 | What professional certifications should a Financial Adviser hold? | 25 | dipfa | Financial Analyst (p26) and Financial Controller (p27) are the next two pages, both also 'Financial ___' roles requiring a Finance degree. |
| 6 | What degree field is required for a Financial Analyst? | 26 | economics | Yes |
| 7 | What credential is preferred for a Financial Controller? | 27 | cma | Yes |
| 8 | What programming languages should a Software Engineer have experience with? | 66 | spring framework | Software Security Engineer (p67), System Security Engineer (p68), and Systems Engineer (p69) are the next three pages - all technical roles sharing heavy vocabulary overlap ('security', 'BS degree in Computer Science'). |
| 9 | What does a Software Security Engineer focus on improving? | 67 | secure coding | Yes |
| 10 | What kind of tools does a System Security Engineer work with? | 68 | intrusion detection | Yes |
| 11 | What automation tools should a Systems Engineer be familiar with? | 69 | puppet | Yes |
| 12 | What equipment does a Warehouse Associate need to operate? | 132 | pallet jack | Warehouse Manager (p133), Warehouse Supervisor (p134), and Warehouse Worker (p135) are the next three pages, same title pattern. |
| 13 | What qualifications are needed to become a registered Nurse? | 98 | diploma in nursing | — |
| 14 | What equipment or technology does a Truck Driver use on the job? | 131 | avl | — |
| 15 | What is the overall goal of a Police Officer's role? | 121 | high-visibility | — |
| 16 | What does a Kindergarten Teacher need to understand about students? | 150 | child development | — |
| 17 | What areas of law does a Corporate Attorney typically handle? | 144 | intellectual property | — |
| 18 | What design software should a Graphic Designer be proficient in? | 168 | illustrator | — |
| 19 | What kind of example is a Store Manager expected to set? | 184 | shining example | — |
| 20 | What does a Digital Marketing Manager plan and measure? | 158 | conversion tests | — |