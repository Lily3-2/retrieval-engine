"""
benchmark/baseline_rag.py
---------------------------
A conventional / "normal" RAG pipeline, built to the same architecture used
by the vast majority of production RAG stacks:

    flatten document -> fixed-size overlapping chunks -> embed each chunk
    as a vector -> store vectors in a flat index -> cosine-similarity
    top-k search at query time -> feed retrieved chunks to a generator.

Two honest caveats, stated up front:

1. **Embeddings.** This sandbox has no network access, so real neural
   embedding models (OpenAI/Voyage/sentence-transformers) can't be
   downloaded. We use TF-IDF vectors instead. TF-IDF *is* a genuine vector
   embedding (each chunk becomes a point in a fixed-dimensional vector
   space, compared via cosine similarity) - it isolates the architectural
   variable we care about (flat chunking + vector search vs. hierarchical
   tree + deterministic traversal) but will UNDER-state real dense
   embeddings' advantage on paraphrase / semantic queries, since TF-IDF,
   like BM25, is still fundamentally lexical. This is called out again in
   EVALUATION_REPORT.md.
2. **Chunking ignores document structure** on purpose - this is the
   single most common real-world implementation of "normal RAG", and is
   exactly the design choice the tree-based system is meant to improve on.

To keep the comparison about *retrieval*, not generation, the same
extractive answer-selection logic (score sentences by query-term overlap,
de-duplicate, concatenate) is used for both systems.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from vectorless_rag.ingestion.parser import ingest


_TOKEN_RE = re.compile(r"[a-z0-9]+")


def simple_tokenize(text: str) -> List[str]:
    """Plain tokenizer with NO stemming - deliberately independent of the
    tree system's tokenizer, so the two pipelines are truly separate
    implementations rather than sharing a hidden advantage."""
    return _TOKEN_RE.findall(text.lower())


@dataclass
class Chunk:
    text: str
    chunk_id: int
    page_majority: int          # which source page most of this chunk overlaps (eval-only metadata)
    pages_touched: Tuple[int, ...]


@dataclass
class RetrievedChunk:
    chunk: Chunk
    score: float


@dataclass
class BaselineResponse:
    query: str
    answer_summary: str
    top_chunks: List[RetrievedChunk]


class NaiveRAGPipeline:
    """Conventional flat-chunk + TF-IDF-vector + cosine-similarity RAG."""

    def __init__(self, chunk_words: int = 120, overlap_words: int = 20, top_k: int = 4):
        self.chunk_words = chunk_words
        self.overlap_words = overlap_words
        self.top_k = top_k
        self.chunks: List[Chunk] = []
        self.vectorizer: TfidfVectorizer = None
        self.matrix = None
        self._built = False

    # ------------------------------------------------------------------
    def add_document(self, path: str) -> None:
        raw_doc = ingest(path)

        # Flatten the whole document to plain text, ignoring headings/
        # sections/page structure - exactly what naive chunkers do -
        # while keeping a word-index -> page map for evaluation only.
        words: List[str] = []
        word_page: List[int] = []
        for raw_page in raw_doc.pages:
            for block in raw_page.blocks:
                for w in block.text.split():
                    words.append(w)
                    word_page.append(raw_page.page_num)

        step = max(1, self.chunk_words - self.overlap_words)
        i = 0
        while i < len(words):
            window_words = words[i:i + self.chunk_words]
            window_pages = word_page[i:i + self.chunk_words]
            if not window_words:
                break
            text = " ".join(window_words)
            pages_touched = tuple(sorted(set(window_pages)))
            # majority page = the page most of this chunk's words belong to
            majority = max(set(window_pages), key=window_pages.count)
            self.chunks.append(Chunk(text=text, chunk_id=len(self.chunks),
                                      page_majority=majority, pages_touched=pages_touched))
            i += step
        self._built = False

    def build(self) -> None:
        if not self.chunks:
            self._built = True
            return
        texts = [c.text for c in self.chunks]
        self.vectorizer = TfidfVectorizer(stop_words="english", lowercase=True)
        self.matrix = self.vectorizer.fit_transform(texts)
        self._built = True

    # ------------------------------------------------------------------
    def query(self, query_text: str, top_k: int = None) -> BaselineResponse:
        if not self._built:
            self.build()
        k = top_k or self.top_k
        if not self.chunks or self.vectorizer is None:
            return BaselineResponse(query=query_text,
                                     answer_summary="The index is empty - add and build documents first.",
                                     top_chunks=[])

        query_vec = self.vectorizer.transform([query_text])
        sims = cosine_similarity(query_vec, self.matrix)[0]

        ranked_idx = np.argsort(-sims)
        top_chunks = []
        for idx in ranked_idx[:k]:
            if sims[idx] <= 0:
                break
            top_chunks.append(RetrievedChunk(chunk=self.chunks[idx], score=float(sims[idx])))

        answer = self._extractive_answer(query_text, top_chunks)
        return BaselineResponse(query=query_text, answer_summary=answer, top_chunks=top_chunks)

    # ------------------------------------------------------------------
    def _extractive_answer(self, query: str, top_chunks: List[RetrievedChunk],
                            max_sentences: int = 5) -> str:
        if not top_chunks:
            return "No sufficiently relevant content was found in the indexed documents for this query."

        query_terms = set(simple_tokenize(query))
        sentence_re = re.compile(r"(?<=[.!?])\s+")

        scored = []
        for rc in top_chunks:
            for sent in sentence_re.split(rc.chunk.text):
                sent = sent.strip()
                if not sent:
                    continue
                overlap = len(set(simple_tokenize(sent)) & query_terms)
                if overlap == 0:
                    continue
                scored.append((overlap, rc.chunk.page_majority, sent))

        scored.sort(key=lambda t: t[0], reverse=True)

        selected = []
        selected_sets = []
        for _, page, sent in scored:
            if len(selected) >= max_sentences:
                break
            tokens = set(simple_tokenize(sent))
            if any(_jaccard(tokens, s) >= 0.7 for s in selected_sets):
                continue
            selected.append((page, sent))
            selected_sets.append(tokens)

        if not selected:
            return "No sufficiently relevant content was found in the indexed documents for this query."

        selected.sort(key=lambda p: p[0])
        return " ".join(f"{s} (~p.{p})" for p, s in selected)


def _jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)
