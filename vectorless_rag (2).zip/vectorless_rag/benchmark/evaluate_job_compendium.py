"""
benchmark/evaluate_job_compendium.py
---------------------------------------
Runs the same head-to-head evaluation as evaluation.py, but against a
real user-supplied document: a 185-page "Job Description Compendium"
(Workable) containing ~150 job-description templates grouped into 10
departments (Accounting/Finance, Admin/Customer Service, Computing/IT,
Real Estate/Engineering/Construction, Healthcare/Pharma, Hospitality/
Travel, Law Enforcement/Security/Logistics, HR/Legal/Education/Training,
Marketing/PR/Media, Sales/Retail).

This document is a particularly good stress test because it's naturally
full of near-duplicate titles sitting on adjacent pages (Accounting Clerk
/ Accounting Manager / Accounts Payable Clerk / Accounts Receivable Clerk
all within 4 pages of each other; Software Engineer / Software Security
Engineer / System Security Engineer / Systems Engineer likewise) - the
exact scenario that breaks retrieval systems with no structural awareness.

Run with:  python -m vectorless_rag.benchmark.evaluate_job_compendium
"""

from __future__ import annotations

import os

from vectorless_rag.benchmark.evaluation import (
    QAItem, evaluate_tree_pipeline, evaluate_baseline_pipeline, print_report,
)

DOC_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "sample_docs", "job_description_compendium.pdf")

QA_SET = [
    # --- Accounting/Finance "clerk" cluster: pages 16-19, near-identical wording ---
    QAItem("What are the requirements to become an Accounting Clerk?",
           ["aptitude for numbers"], 16, distractor=True,
           note="Accounting Manager (p17), Accounts Payable Clerk (p18), and Accounts "
                "Receivable Clerk (p19) sit on immediately adjacent pages with very "
                "similar wording ('accounting', 'clerk', 'BS degree', 'MS Office' all recur)."),
    QAItem("What does an Accounts Payable Clerk do on a daily basis?",
           ["payment cycle"], 18, distractor=True),
    QAItem("What are an Accounts Receivable Clerk's main responsibilities?",
           ["bill reminders"], 19, distractor=True),
    QAItem("What does an Accounting Manager oversee?",
           ["annual audits"], 17, distractor=True),

    # --- Financial cluster: pages 25-27, all "Financial ___" with BS degree in Finance ---
    QAItem("What professional certifications should a Financial Adviser hold?",
           ["dipfa"], 25, distractor=True,
           note="Financial Analyst (p26) and Financial Controller (p27) are the next "
                "two pages, both also 'Financial ___' roles requiring a Finance degree."),
    QAItem("What degree field is required for a Financial Analyst?",
           ["economics"], 26, distractor=True),
    QAItem("What credential is preferred for a Financial Controller?",
           ["cma"], 27, distractor=True),

    # --- Software/Systems engineering cluster: pages 66-69 ---
    QAItem("What programming languages should a Software Engineer have experience with?",
           ["spring framework"], 66, distractor=True,
           note="Software Security Engineer (p67), System Security Engineer (p68), and "
                "Systems Engineer (p69) are the next three pages - all technical roles "
                "sharing heavy vocabulary overlap ('security', 'BS degree in Computer Science')."),
    QAItem("What does a Software Security Engineer focus on improving?",
           ["secure coding"], 67, distractor=True),
    QAItem("What kind of tools does a System Security Engineer work with?",
           ["intrusion detection"], 68, distractor=True),
    QAItem("What automation tools should a Systems Engineer be familiar with?",
           ["puppet"], 69, distractor=True),

    # --- One more cluster example: warehouse roles p132-135 ---
    QAItem("What equipment does a Warehouse Associate need to operate?",
           ["pallet jack"], 132, distractor=True,
           note="Warehouse Manager (p133), Warehouse Supervisor (p134), and Warehouse "
                "Worker (p135) are the next three pages, same title pattern."),

    # --- Standalone roles (not immediately adjacent to a near-duplicate title) ---
    QAItem("What qualifications are needed to become a registered Nurse?",
           ["diploma in nursing"], 98),
    QAItem("What equipment or technology does a Truck Driver use on the job?",
           ["avl"], 131),
    QAItem("What is the overall goal of a Police Officer's role?",
           ["high-visibility"], 121),
    QAItem("What does a Kindergarten Teacher need to understand about students?",
           ["child development"], 150),
    QAItem("What areas of law does a Corporate Attorney typically handle?",
           ["intellectual property"], 144),
    QAItem("What design software should a Graphic Designer be proficient in?",
           ["illustrator"], 168),
    QAItem("What kind of example is a Store Manager expected to set?",
           ["shining example"], 184),
    QAItem("What does a Digital Marketing Manager plan and measure?",
           ["conversion tests"], 158),
]


if __name__ == "__main__":
    from vectorless_rag.retrieval.ranker import RankerWeights

    print(f"Document: {DOC_PATH}")
    print(f"Question set: {len(QA_SET)} questions "
          f"({sum(1 for q in QA_SET if q.distractor)} distractor / "
          f"{sum(1 for q in QA_SET if not q.distractor)} standalone)\n")

    # This document contains department table-of-contents pages (short,
    # keyword-dense) that exploit BM25's length-normalization bias against
    # the default ranker weights - see EVALUATION_REPORT_JOB_COMPENDIUM.md
    # §3-4 for the full investigation. short_page_token_threshold/penalty
    # fixes it here with no regression on the other sample document.
    default_weights = RankerWeights()
    tuned_weights = RankerWeights(short_page_token_threshold=30, short_page_penalty=0.4)

    print("--- Tree pipeline with DEFAULT ranker weights (for comparison) ---")
    tree_default = evaluate_tree_pipeline(doc_path=DOC_PATH, qa_set=QA_SET,
                                           name="Vectorless Tree RAG (default)",
                                           ranker_weights=default_weights)
    print(f"Page-hit@1: {tree_default.hit_at_1*100:.1f}%  |  MRR: {tree_default.mrr:.3f}\n")

    print("--- Full comparison: Tree (tuned weights) vs. Baseline ---")
    tree_tuned = evaluate_tree_pipeline(doc_path=DOC_PATH, qa_set=QA_SET,
                                         name="Vectorless Tree RAG (tuned)",
                                         ranker_weights=tuned_weights)
    baseline_result = evaluate_baseline_pipeline(doc_path=DOC_PATH, qa_set=QA_SET,
                                                  name="Baseline Vector RAG (TF-IDF + cosine)")
    print_report(tree_tuned, baseline_result)
