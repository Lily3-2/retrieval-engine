# Evaluation Report: Job Description Compendium (user-supplied document)

## 1. Document

**`job_description_compendium.pdf`** — a real 185-page document ("Job Description Compendium" by Workable), containing roughly 150 job-description templates grouped into 10 departments (Accounting/Finance, Admin/Customer Service, Computing/IT, Real Estate/Engineering/Construction, Healthcare/Pharma, Hospitality/Travel, Law Enforcement/Security/Logistics, HR/Legal/Education/Training, Marketing/PR/Media, Sales/Retail). Each job template has its own page with `Job brief`, `Responsibilities`, and `Requirements` sections.

This is naturally a harder, more realistic stress test than a hand-built sample: **near-duplicate job titles sit on immediately adjacent pages** (Accounting Clerk → Accounting Manager → Accounts Payable Clerk → Accounts Receivable Clerk, all within 4 pages; Software Engineer → Software Security Engineer → System Security Engineer → Systems Engineer likewise), sharing heavy vocabulary overlap ("BS degree", "MS Office", "experience"). The document also contains **department table-of-contents pages** that list every job title in that department as a short block of text — a structural feature that turned out to matter a lot (see §3).

## 2. Methodology

Same harness as `EVALUATION_REPORT.md`: 20 hand-written questions, 12 of them targeting a near-duplicate-title cluster (marked distractor), 8 targeting standalone roles. Full question list with expected pages/keywords: [`sample_docs/job_compendium_sample_queries.md`](sample_docs/job_compendium_sample_queries.md).

## 3. First run: an honest surprise

With the tree system's **default** ranking weights (the same ones used in `EVALUATION_REPORT.md`, where they won across the board), the baseline actually came out slightly ahead on this document:

| Metric | Tree (default weights) | Baseline |
|---|---|---|
| Page-hit@1 | 60.0% | **65.0%** |
| MRR | 0.767 | **0.787** |
| Distractor-subset hit@1 | 41.7% | **66.7%** |

**Root cause.** Every one of the tree system's misses (6 of 8) landed on the same page: the department's table-of-contents page (e.g. page 14, "ACCOUNTING/FINANCE", which simply lists "...Financial adviser Financial analyst Financial controller..." as a single short block of text). Querying the live index directly showed exactly why:

```
Query: "What professional certifications should a Financial Adviser hold?"
#1  page 14 (dept. TOC)      score 17.486   tokens_on_page 25
#2  page 25 (correct answer) score 17.444   tokens_on_page 51
```

BM25 normalizes term frequency by document length, so a page with only 25 tokens needs far fewer raw keyword matches to look just as relevant as a 51-token page discussing the topic properly — and because the TOC page's own section is literally titled "ACCOUNTING/FINANCE", it also picked up the ranker's heading-match bonus for any finance-related query. Short, dense, keyword-heavy pages (indexes, tables of contents, glossaries) are the one content type that genuinely fools this scoring approach — a real, reproducible limitation, not a hypothetical one. The baseline was *less* susceptible here only because its fixed-width chunks blend TOC text together with neighboring pages, diluting the effect - it wasn't retrieving more accurately by design, it was accidentally protected by chunk-boundary noise.

## 4. The fix

`retrieval/ranker.py` already exposes `RankerWeights` as a tunable, so this was fixed with a config change rather than new code paths: two new opt-in fields, `short_page_token_threshold` and `short_page_penalty`, reduce a page's ranking multiplier when its token count falls below a threshold — directly countering BM25's short-document bias for this kind of corpus. Left at 0/0 (off) by default so nothing about the earlier CloudGuard result changes unless you opt in.

Sweeping threshold/penalty combinations on **both** documents at once:

| Setting | Job Compendium hit@1 | CloudGuard hit@1 |
|---|---|---|
| default (0 / 0, i.e. off) | 60.0% | 95.0% |
| threshold=30, penalty=0.4 | **95.0%** | **95.0%** |
| threshold=35, penalty=0.5 | 95.0% | 90.0% |
| threshold=40, penalty=0.6 | 75.0% | 80.0% |
| threshold=50, penalty=0.7 | 55.0% | 80.0% |

`threshold=30, penalty=0.4` fixes the job-compendium problem with **zero regression** on CloudGuard - it's mild enough to only touch genuinely tiny pages. Heavier penalties overcorrect: they start punishing legitimately short pages that happen to be the right answer (visible in the CloudGuard column dropping as the penalty grows). This is a real tuning tradeoff, not a free lunch - which is exactly why it ships as an opt-in parameter rather than a new default.

```python
from vectorless_rag.pipeline import RAGPipeline
from vectorless_rag.retrieval.ranker import RankerWeights

pipeline = RAGPipeline(
    ranker_weights=RankerWeights(short_page_token_threshold=30, short_page_penalty=0.4)
)
```

## 5. Final results (tree with tuned weights vs. baseline)

| Metric | Vectorless Tree (tuned) | Baseline Vector RAG |
|---|---|---|
| Page-hit@1 | **95.0%** | 65.0% |
| Page-hit@3 | 95.0% | 95.0% |
| MRR | **0.950** | 0.787 |
| Answer keyword hit-rate | **70.0%** | 60.0% |
| Distractor-subset hit@1 | **91.7%** | 66.7% |
| Distractor-subset answer hit-rate | 66.7% | 66.7% |
| Build time (s), 185-page PDF | 1.609 | 1.537 |
| Mean query latency (ms) | 6.46 | 1.29 |
| Deterministic | True | True |

### Per-question breakdown (tuned tree vs. baseline)

| # | Distractor? | Question | Expected page | Tree top page | Baseline top page | Tree hit@1 | Baseline hit@1 |
|---|---|---|---|---|---|---|---|
| 1 | Y | What are the requirements to become an Accounting Clerk? | 16 | 16 | 15 | ✅ | ❌ |
| 2 | Y | What does an Accounts Payable Clerk do on a daily basis? | 18 | 18 | 18 | ✅ | ✅ |
| 3 | Y | What are an Accounts Receivable Clerk's main responsibilities? | 19 | 19 | 19 | ✅ | ✅ |
| 4 | Y | What does an Accounting Manager oversee? | 17 | 17 | 16 | ✅ | ❌ |
| 5 | Y | What professional certifications should a Financial Adviser hold? | 25 | 25 | 25 | ✅ | ✅ |
| 6 | Y | What degree field is required for a Financial Analyst? | 26 | 26 | 26 | ✅ | ✅ |
| 7 | Y | What credential is preferred for a Financial Controller? | 27 | 27 | 27 | ✅ | ✅ |
| 8 | Y | What programming languages should a Software Engineer have experience with? | 66 | 66 | 74 | ✅ | ❌ |
| 9 | Y | What does a Software Security Engineer focus on improving? | 67 | 67 | 67 | ✅ | ✅ |
| 10 | Y | What kind of tools does a System Security Engineer work with? | 68 | 68 | 68 | ✅ | ✅ |
| 11 | Y | What automation tools should a Systems Engineer be familiar with? | 69 | 56 | 71 | ❌ | ❌ |
| 12 | Y | What equipment does a Warehouse Associate need to operate? | 132 | 132 | 132 | ✅ | ✅ |
| 13 |  | What qualifications are needed to become a registered Nurse? | 98 | 98 | 98 | ✅ | ✅ |
| 14 |  | What equipment or technology does a Truck Driver use on the job? | 131 | 131 | 130 | ✅ | ❌ |
| 15 |  | What is the overall goal of a Police Officer's role? | 121 | 121 | 120 | ✅ | ❌ |
| 16 |  | What does a Kindergarten Teacher need to understand about students? | 150 | 150 | 149 | ✅ | ❌ |
| 17 |  | What areas of law does a Corporate Attorney typically handle? | 144 | 144 | 144 | ✅ | ✅ |
| 18 |  | What design software should a Graphic Designer be proficient in? | 168 | 168 | 168 | ✅ | ✅ |
| 19 |  | What kind of example is a Store Manager expected to set? | 184 | 184 | 184 | ✅ | ✅ |
| 20 |  | What does a Digital Marketing Manager plan and measure? | 158 | 158 | 158 | ✅ | ✅ |

## 6. The one remaining shared failure

Question 11 ("What automation tools should a Systems Engineer be familiar with?", expected page 69) is wrong for **both** systems - tree picks page 56 (Embedded Software Engineer), baseline picks page 71 (Telecommunications Specialist). Unlike the TOC-page problem, this is genuine content ambiguity: "systems", "engineer", "BS degree in Computer Science" are shared vocabulary across half a dozen IT roles in this document, and nothing about page structure disambiguates them - the word "systems" alone doesn't tell you which of five systems-adjacent job titles is meant. This is the same class of limitation noted in the CloudGuard report: lexical retrieval (BM25 or TF-IDF) can't out-perform the vocabulary actually available in the query and the source text.

## 7. Verdict for this document

With default settings, this document would have been a **wash, arguably a narrow loss** for the tree system - a genuinely useful negative result, since it surfaced a real failure mode (TOC/index pages exploiting BM25's length-normalization bias) that the cleaner CloudGuard manual never exercised. With the tuned ranker weights, the tree system wins decisively (95% vs 65% hit@1, 91.7% vs 66.7% on the hardest distractor questions) while costing nothing on the document where it already excelled.

**Takeaway that generalizes beyond this one document:** any corpus with index pages, tables of contents, glossaries, or appendix tables mixed in with substantive content pages should use `short_page_token_threshold` / `short_page_penalty` - or, better, actively exclude clearly-non-prose pages (detect via bullet-density, average line length, or a dedicated 'index page' heuristic) from full-strength page ranking. This project doesn't do that detection automatically yet; it's the most concrete next improvement this evaluation surfaced.

The TF-IDF-vs-real-embeddings caveat from `EVALUATION_REPORT.md` applies identically here.
