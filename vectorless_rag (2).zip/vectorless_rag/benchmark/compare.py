"""
benchmark/compare.py
----------------------
Generic side-by-side comparison: run YOUR OWN document and YOUR OWN
questions through both the vectorless tree pipeline and the baseline
vector RAG pipeline, and print what each one retrieved and answered.

Unlike evaluation.py, this does NOT require a ground-truth answer key -
it's for eyeballing real differences on your own content, not computing
accuracy metrics. If you want metrics (hit-rate, MRR, etc.) on your own
document, see the "Building your own ground-truth eval" section in
EVALUATION_REPORT.md / README.md - you'll need to supply the expected
page/keywords per question the same way QA_SET does in evaluation.py.

Usage
-----
    python -m vectorless_rag.benchmark.compare path/to/your_doc.pdf \\
        "What is the return policy?" \\
        "How long is the warranty?"

    # or edit QUESTIONS below and run with no args to use the sample doc
"""

from __future__ import annotations

import sys
import os

from vectorless_rag.pipeline import RAGPipeline
from vectorless_rag.benchmark.baseline_rag import NaiveRAGPipeline

DEFAULT_DOC = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "sample_docs", "cloudguard_manual.md")
DEFAULT_QUESTIONS = [
    "What is the minimum password length?",
    "How long is the trial period?",
]


def compare(doc_path: str, questions: list[str]) -> None:
    print(f"Indexing '{doc_path}' with both pipelines...\n")

    tree = RAGPipeline(top_k_pages=5)
    tree.add_document(doc_path)
    tree.build()

    baseline = NaiveRAGPipeline(chunk_words=120, overlap_words=20, top_k=4)
    baseline.add_document(doc_path)
    baseline.build()

    for q in questions:
        print("=" * 90)
        print(f"QUESTION: {q}\n")

        t_resp = tree.query(q)
        b_resp = baseline.query(q)

        print("-- Vectorless Tree RAG --")
        if t_resp.ranked_pages:
            pages = [f"p.{rp.node.page_start}(score={rp.score})" for rp in t_resp.ranked_pages]
            print(f"Top pages: {pages}")
        else:
            print("Top pages: (no match)")
        print(f"Answer: {t_resp.answer_summary}\n")

        print("-- Baseline Vector RAG (TF-IDF + cosine) --")
        if b_resp.top_chunks:
            pages = [f"p.{rc.chunk.page_majority}(score={rc.score:.3f})" for rc in b_resp.top_chunks]
            print(f"Top chunk pages: {pages}")
        else:
            print("Top chunk pages: (no match)")
        print(f"Answer: {b_resp.answer_summary}\n")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        doc = sys.argv[1]
        qs = sys.argv[2:] or DEFAULT_QUESTIONS
    else:
        doc = DEFAULT_DOC
        qs = DEFAULT_QUESTIONS
    compare(doc, qs)
