# Evaluation Report: Vectorless Tree RAG vs. Conventional Vector RAG

## 1. Methodology

**Document under test:** `sample_docs/cloudguard_manual.md` — a 9-page synthetic technical manual (CloudGuard Platform Admin & Security Manual) covering installation, auth, encryption, backup/DR, monitoring, compliance, licensing, and troubleshooting. It was written specifically to include **distractor collisions**: the same or similar numbers (e.g. "15 minutes", "90 days", "30 …", "443") appear multiple times across different sections in different meanings — the classic case that breaks naive retrieval.

**Systems compared:**

- **Vectorless Tree RAG** (this project): AST tree with page-level hierarchy, BM25-style deterministic scoring aggregated bottom-up, DFS traversal with subtree pruning, structural page ranking (heading match / position / density).
- **Baseline Vector RAG**: the architecture most production RAG systems actually use — flatten the document, split into fixed-size overlapping chunks (120 words, 20-word overlap) ignoring section/page boundaries, embed each chunk as a vector, retrieve top-k by cosine similarity.

**Honest caveat:** this sandbox has no network access, so real neural embedding models (OpenAI/Voyage/sentence-transformers) could not be downloaded. The baseline uses **TF-IDF vectors** instead of neural embeddings. TF-IDF is a genuine vector embedding (cosine similarity over a fixed-dimensional space) and isolates the architectural variable this experiment is about — flat chunking + vector search vs. hierarchical tree + deterministic traversal — but it will *understate* real dense embeddings' advantage on paraphrase/semantic queries, since TF-IDF, like BM25, is still fundamentally lexical. See §4 for what would likely change with real embeddings.

To isolate retrieval quality from generation quality, **both systems use the same style of extractive answer generation** (score sentences by query-term overlap, de-duplicate near-identical sentences, concatenate) — implemented independently for each system with its own tokenizer, so neither has a hidden shared advantage.

**Question set:** 20 hand-written factual questions with known expected page and expected keyword(s)/number(s) in the answer. 8 of the 20 are marked as *distractor questions* — their correct answer's number/term also appears elsewhere in the document in an unrelated context.

## 2. Results

| Metric | Vectorless Tree RAG | Baseline Vector RAG |
|---|---|---|
| Page-hit@1 (all 20 Qs) | **95.0%** | 85.0% |
| Page-hit@3 (all 20 Qs) | **100.0%** | 90.0% |
| MRR (all 20 Qs) | **0.975** | 0.875 |
| Answer keyword hit-rate | 100.0% | 100.0% |
| Distractor-subset hit@1 | **87.5%** | 75.0% |
| Distractor-subset answer hit-rate | 100.0% | 100.0% |
| Build time (s), 9-page doc | 0.0025 | 0.0042 |
| Mean query latency (ms) | 0.42 | 0.72 |
| Deterministic (identical output on repeat query) | True | True |

### Per-question breakdown

| # | Distractor? | Question | Expected page | Tree top page | Baseline top page | Tree hit@1 | Baseline hit@1 |
|---|---|---|---|---|---|---|---|
| 1 |  | What is the minimum password length? | 3 | 3 | 3 | ✅ | ✅ |
| 2 | Y | How often must API keys be rotated when a max lifetime is configured? | 3 | 3 | 3 | ✅ | ✅ |
| 3 | Y | How long does a web console session stay active before timing out? | 3 | 3 | 3 | ✅ | ✅ |
| 4 | Y | How often does the Control Plane save a configuration snapshot to disk? | 5 | 3 | 4 | ❌ | ❌ |
| 5 | Y | What is the disaster recovery Recovery Point Objective (RPO)? | 5 | 5 | 5 | ✅ | ✅ |
| 6 | Y | How long are full database backups retained? | 5 | 5 | 5 | ✅ | ✅ |
| 7 |  | What encryption algorithm protects data at rest? | 4 | 4 | 4 | ✅ | ✅ |
| 8 |  | Which older TLS versions are disabled for inter-component traffic? | 4 | 4 | 4 | ✅ | ✅ |
| 9 |  | How often are data encryption keys automatically rotated? | 4 | 4 | 4 | ✅ | ✅ |
| 10 |  | What compliance certifications does CloudGuard hold? | 7 | 7 | 6 | ✅ | ❌ |
| 11 | Y | How long is the trial period for a new account? | 8 | 8 | 7 | ✅ | ❌ |
| 12 |  | What is the API rate limit for read operations? | 6 | 6 | 6 | ✅ | ✅ |
| 13 |  | What is the API rate limit for write operations? | 6 | 6 | 6 | ✅ | ✅ |
| 14 |  | What is the maximum API request or file upload size? | 6 | 6 | 6 | ✅ | ✅ |
| 15 | Y | What port is used for PostgreSQL replication between Control Plane nodes? | 2 | 2 | 2 | ✅ | ✅ |
| 16 |  | How many vCPUs and how much RAM does the Control Plane require at minimum? | 2 | 2 | 2 | ✅ | ✅ |
| 17 |  | What is the disaster recovery Recovery Time Objective (RTO)? | 5 | 5 | 5 | ✅ | ✅ |
| 18 |  | What error rate threshold triggers an alert? | 6 | 6 | 6 | ✅ | ✅ |
| 19 | Y | How long until a revoked API key is rejected across all Edge Proxy nodes? | 3 | 3 | 3 | ✅ | ✅ |
| 20 |  | How long does data residency configuration typically take to complete? | 7 | 7 | 7 | ✅ | ✅ |

## 3. Discussion

**Where the tree system wins.** The baseline misses 3 of 20 questions (#4, #10, #11); the tree misses only 1 (#4, shared with the baseline — see below). On #10 and #11, both systems retrieve chunks/pages with real term overlap, but the baseline's top chunk is from an adjacent, topically-similar section, because a flat 120-word window has no way to weight *where in the document's structure* a match occurs. The tree system's page ranking directly rewards a match that also hits the enclosing section's heading (§7 "Compliance and Certifications" matching the compliance question, §8 "Trial Accounts and Licensing" matching the trial-period question) — structural information the baseline discards at chunking time.

**Where both systems fail the same way.** Question #4 (config snapshot interval) is answered wrong by *both* systems, and for a legitimate reason: the source document itself mentions the '15-minute configuration snapshot' in passing on page 3 (while explaining session timeouts) before defining it properly on page 5. Neither a BM25 tree nor a cosine-similarity baseline can resolve genuine textual ambiguity that the author themselves created by cross-referencing — this is a limit of lexical retrieval in general, not a defect unique to either architecture.

**Why answer-hit-rate is 100% for both despite different page rankings.** Both pipelines retrieve several pages/chunks (top-3 / top-4), not just the #1 result, before generating the final answer. So even when page ranking put the *correct* page at #2 or #3 instead of #1, the answer generator still saw it and pulled the right sentence. This matters: **page-hit@1 and MRR are the metrics that actually differentiate these two systems** — final-answer quality alone doesn't, because a generous top-k masks ranking mistakes. In a lower top-k or single-page-context deployment (e.g. citing exactly one page to a user, or a tight LLM context budget), the tree system's ranking advantage would show up directly in answer quality too.

**Cost side.** Both systems are extremely cheap at this document size (single-digit milliseconds). The gap would widen with scale: the baseline's cosine-similarity search is O(chunks) per query and its accuracy depends entirely on chunk-boundary luck; the tree system's pruning during traversal skips whole irrelevant subtrees, and its ranking is a closed-form function of already-aggregated statistics — no nearest-neighbour index to build, maintain, or re-embed on document updates.

## 4. What would change with real neural embeddings

This experiment used TF-IDF, not neural embeddings, for the baseline (see caveat above), so it mainly measures **flat chunking vs. hierarchical structure**, not **lexical vs. semantic matching**. With real dense embeddings, the baseline would likely close some of this gap on *paraphrased* queries — e.g. asking "how long before an idle admin gets kicked out of the dashboard" instead of "session timeout" — since neural embeddings can match meaning without shared vocabulary, whereas both BM25 and TF-IDF need overlapping terms (the vectorless system's light stemmer only handles simple morphology, not synonyms). Neural embeddings would **not**, however, fix a genuine cross-reference ambiguity like #4 by themselves — the source text itself mentions the same fact in two places, so both a lexical and a semantic matcher can legitimately prefer the wrong one. Embeddings *might* help the baseline's #10/#11 misses, since those are chunk-boundary artifacts rather than true ambiguity — but that's a hypothesis this experiment can't test without network access to a real embedding model. A production system could combine both approaches: hierarchical, deterministic tree ranking for structure and precision, with embeddings (or a hybrid BM25+embedding score) layered in for paraphrase recall.

## 5. Verdict

**For this kind of document (structured technical/policy manual, precise factual/numeric questions, deterministic-answer requirements):** the vectorless tree system is better. It won on every retrieval-ranking metric (page-hit@1, page-hit@3, MRR, and the distractor subset specifically), needs no vector index or embedding model, is fully deterministic and explainable (every score decomposes into which terms matched, at which node), and costs less to build and query.

**Where a conventional embedding-based system would likely be better:** unstructured or lightly-structured text (chat transcripts, freeform notes), queries that are heavily paraphrased relative to the source wording, and cross-lingual or synonym-heavy retrieval — cases where semantic similarity beats term overlap regardless of document structure.

**Bottom line:** the win here isn't "BM25 beats embeddings" in general — it's that *documents with real hierarchical structure (manuals, contracts, reports, policies) retrieve more precisely when the retrieval system is structure-aware*, regardless of whether the underlying match is lexical or semantic. The ideal production system for that kind of content is arguably this tree structure with an embedding-based (or hybrid) scorer swapped in for `BM25Scorer` — keeping the hierarchy and ranking logic, upgrading only the term-overlap step to a learned one.
