"""
benchmark/evaluation.py
-------------------------
Runs both RAG systems against the same document and the same 20-question
ground-truth set, and reports:

  * Page-hit@1     - did the #1 ranked page/chunk actually contain the answer?
  * Page-hit@3     - was the correct page anywhere in the top 3?
  * MRR            - mean reciprocal rank of the first correct page
  * Answer-hit     - does the generated answer text contain an expected keyword/number?
  * Distractor subset - the same 3 metrics, restricted to questions whose
    answer is a number/term that ALSO appears elsewhere in the document in a
    different context (the classic naive-RAG failure mode)
  * Build time / mean query latency
  * Determinism - running the same query twice yields byte-identical output

Run with:  python -m vectorless_rag.benchmark.evaluation
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import List

from vectorless_rag.pipeline import RAGPipeline
from vectorless_rag.benchmark.baseline_rag import NaiveRAGPipeline

DOC_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "sample_docs", "cloudguard_manual.md")


@dataclass
class QAItem:
    question: str
    expected_keywords: List[str]   # any one of these appearing in the answer counts as correct
    expected_page: int
    distractor: bool = False       # True if the correct answer's number/term recurs elsewhere
    note: str = ""


QA_SET: List[QAItem] = [
    QAItem("What is the minimum password length?", ["12"], 3),
    QAItem("How often must API keys be rotated when a max lifetime is configured?",
           ["90 days"], 3, distractor=True,
           note="90 days also appears as password-expiry (p3) and audit-log retention (p7)"),
    QAItem("How long does a web console session stay active before timing out?",
           ["15 minutes"], 3, distractor=True,
           note="15 minutes also appears as config snapshot interval (p3/p5) and RPO (p5)"),
    QAItem("How often does the Control Plane save a configuration snapshot to disk?",
           ["15 minutes"], 5, distractor=True,
           note="15 minutes also appears as web console session timeout (p3) and RPO (p5)"),
    QAItem("What is the disaster recovery Recovery Point Objective (RPO)?",
           ["15 minutes"], 5, distractor=True),
    QAItem("How long are full database backups retained?", ["30 days"], 5, distractor=True,
           note="30 also appears as '30 minutes' lockout (p3) and '30 seconds' health check (p9)"),
    QAItem("What encryption algorithm protects data at rest?", ["aes-256", "aes 256"], 4),
    QAItem("Which older TLS versions are disabled for inter-component traffic?",
           ["tls 1.0", "tls 1.1"], 4),
    QAItem("How often are data encryption keys automatically rotated?", ["180 days"], 4),
    QAItem("What compliance certifications does CloudGuard hold?",
           ["soc 2", "iso 27001", "hipaa"], 7),
    QAItem("How long is the trial period for a new account?", ["14 days"], 8, distractor=True,
           note="Distinct from 90-day and 30-day figures elsewhere in the doc"),
    QAItem("What is the API rate limit for read operations?", ["1000 requests"], 6),
    QAItem("What is the API rate limit for write operations?", ["100 requests"], 6),
    QAItem("What is the maximum API request or file upload size?", ["5 gb"], 6),
    QAItem("What port is used for PostgreSQL replication between Control Plane nodes?",
           ["5432"], 2, distractor=True, note="port 443 recurs on p2 and p9"),
    QAItem("How many vCPUs and how much RAM does the Control Plane require at minimum?",
           ["8 vcpus", "32 gb"], 2),
    QAItem("What is the disaster recovery Recovery Time Objective (RTO)?", ["4 hours"], 5),
    QAItem("What error rate threshold triggers an alert?", ["5%"], 6),
    QAItem("How long until a revoked API key is rejected across all Edge Proxy nodes?",
           ["60 seconds"], 3, distractor=True, note="'30 seconds' health check appears on p9"),
    QAItem("How long does data residency configuration typically take to complete?",
           ["5 business days"], 7),
]


@dataclass
class SystemResult:
    name: str
    build_seconds: float
    hit_at_1: float = 0.0
    hit_at_3: float = 0.0
    mrr: float = 0.0
    answer_hit_rate: float = 0.0
    distractor_hit_at_1: float = 0.0
    distractor_answer_hit_rate: float = 0.0
    mean_latency_ms: float = 0.0
    deterministic: bool = True
    per_question: List[dict] = field(default_factory=list)


def _answer_contains(answer: str, expected_keywords: List[str]) -> bool:
    lowered = answer.lower()
    return any(kw.lower() in lowered for kw in expected_keywords)


def evaluate_tree_pipeline(doc_path: str = None, qa_set: List[QAItem] = None,
                            name: str = "Vectorless Tree RAG",
                            ranker_weights=None) -> SystemResult:
    doc_path = doc_path or DOC_PATH
    qa_set = qa_set if qa_set is not None else QA_SET

    t0 = time.perf_counter()
    pipeline = RAGPipeline(top_k_pages=5, ranker_weights=ranker_weights)
    pipeline.add_document(doc_path)
    pipeline.build()
    build_seconds = time.perf_counter() - t0

    result = SystemResult(name=name, build_seconds=build_seconds)
    reciprocal_ranks, hits1, hits3, ans_hits = [], [], [], []
    d_hits1, d_ans_hits = [], []
    latencies = []
    determinism_ok = True

    for qa in qa_set:
        t0 = time.perf_counter()
        resp = pipeline.query(qa.question, top_k=5)
        latencies.append((time.perf_counter() - t0) * 1000)

        resp2 = pipeline.query(qa.question, top_k=5)
        if resp.answer_summary != resp2.answer_summary:
            determinism_ok = False

        pages_ranked = [rp.node.page_start for rp in resp.ranked_pages]
        hit1 = pages_ranked[:1] == [qa.expected_page]
        hit3 = qa.expected_page in pages_ranked[:3]
        rr = 0.0
        if qa.expected_page in pages_ranked:
            rr = 1.0 / (pages_ranked.index(qa.expected_page) + 1)
        ans_hit = _answer_contains(resp.answer_summary, qa.expected_keywords)

        hits1.append(hit1); hits3.append(hit3); reciprocal_ranks.append(rr); ans_hits.append(ans_hit)
        if qa.distractor:
            d_hits1.append(hit1)
            d_ans_hits.append(ans_hit)

        result.per_question.append(dict(
            question=qa.question, expected_page=qa.expected_page,
            pages_ranked=pages_ranked, hit1=hit1, hit3=hit3, rr=round(rr, 3),
            answer_hit=ans_hit, answer=resp.answer_summary, distractor=qa.distractor,
        ))

    n = len(qa_set)
    result.hit_at_1 = sum(hits1) / n
    result.hit_at_3 = sum(hits3) / n
    result.mrr = sum(reciprocal_ranks) / n
    result.answer_hit_rate = sum(ans_hits) / n
    result.distractor_hit_at_1 = sum(d_hits1) / len(d_hits1) if d_hits1 else 0.0
    result.distractor_answer_hit_rate = sum(d_ans_hits) / len(d_ans_hits) if d_ans_hits else 0.0
    result.mean_latency_ms = sum(latencies) / len(latencies)
    result.deterministic = determinism_ok
    return result


def evaluate_baseline_pipeline(doc_path: str = None, qa_set: List[QAItem] = None,
                                name: str = "Baseline Vector RAG (TF-IDF + cosine)") -> SystemResult:
    doc_path = doc_path or DOC_PATH
    qa_set = qa_set if qa_set is not None else QA_SET

    t0 = time.perf_counter()
    pipeline = NaiveRAGPipeline(chunk_words=120, overlap_words=20, top_k=4)
    pipeline.add_document(doc_path)
    pipeline.build()
    build_seconds = time.perf_counter() - t0

    result = SystemResult(name=name, build_seconds=build_seconds)
    reciprocal_ranks, hits1, hits3, ans_hits = [], [], [], []
    d_hits1, d_ans_hits = [], []
    latencies = []
    determinism_ok = True

    for qa in qa_set:
        t0 = time.perf_counter()
        resp = pipeline.query(qa.question, top_k=4)
        latencies.append((time.perf_counter() - t0) * 1000)

        resp2 = pipeline.query(qa.question, top_k=4)
        if resp.answer_summary != resp2.answer_summary:
            determinism_ok = False

        pages_ranked = [rc.chunk.page_majority for rc in resp.top_chunks]
        hit1 = pages_ranked[:1] == [qa.expected_page]
        hit3 = qa.expected_page in pages_ranked[:3]
        rr = 0.0
        if qa.expected_page in pages_ranked:
            rr = 1.0 / (pages_ranked.index(qa.expected_page) + 1)
        ans_hit = _answer_contains(resp.answer_summary, qa.expected_keywords)

        hits1.append(hit1); hits3.append(hit3); reciprocal_ranks.append(rr); ans_hits.append(ans_hit)
        if qa.distractor:
            d_hits1.append(hit1)
            d_ans_hits.append(ans_hit)

        result.per_question.append(dict(
            question=qa.question, expected_page=qa.expected_page,
            pages_ranked=pages_ranked, hit1=hit1, hit3=hit3, rr=round(rr, 3),
            answer_hit=ans_hit, answer=resp.answer_summary, distractor=qa.distractor,
        ))

    n = len(qa_set)
    result.hit_at_1 = sum(hits1) / n
    result.hit_at_3 = sum(hits3) / n
    result.mrr = sum(reciprocal_ranks) / n
    result.answer_hit_rate = sum(ans_hits) / n
    result.distractor_hit_at_1 = sum(d_hits1) / len(d_hits1) if d_hits1 else 0.0
    result.distractor_answer_hit_rate = sum(d_ans_hits) / len(d_ans_hits) if d_ans_hits else 0.0
    result.mean_latency_ms = sum(latencies) / len(latencies)
    result.deterministic = determinism_ok
    return result


def print_report(tree: SystemResult, baseline: SystemResult) -> None:
    def pct(x): return f"{x * 100:.1f}%"

    print(f"\n{'Metric':40s} {'Vectorless Tree':>18s} {'Baseline Vector':>18s}")
    print("-" * 78)
    rows = [
        ("Page-hit@1 (all 20 questions)", pct(tree.hit_at_1), pct(baseline.hit_at_1)),
        ("Page-hit@3 (all 20 questions)", pct(tree.hit_at_3), pct(baseline.hit_at_3)),
        ("MRR (all 20 questions)", f"{tree.mrr:.3f}", f"{baseline.mrr:.3f}"),
        ("Answer keyword hit-rate", pct(tree.answer_hit_rate), pct(baseline.answer_hit_rate)),
        ("Distractor-subset hit@1", pct(tree.distractor_hit_at_1), pct(baseline.distractor_hit_at_1)),
        ("Distractor-subset answer hit-rate", pct(tree.distractor_answer_hit_rate),
         pct(baseline.distractor_answer_hit_rate)),
        ("Build time (s)", f"{tree.build_seconds:.4f}", f"{baseline.build_seconds:.4f}"),
        ("Mean query latency (ms)", f"{tree.mean_latency_ms:.2f}", f"{baseline.mean_latency_ms:.2f}"),
        ("Deterministic (same query twice)", str(tree.deterministic), str(baseline.deterministic)),
    ]
    for label, a, b in rows:
        print(f"{label:40s} {a:>18s} {b:>18s}")

    print("\n=== PER-QUESTION BREAKDOWN (D = distractor question) ===")
    header = f"{'#':>2} {'D':>2} {'Tree p':>7} {'Base p':>7} {'Exp p':>6} {'Tree1':>6} {'Base1':>6}"
    print(header)
    for i, (tq, bq) in enumerate(zip(tree.per_question, baseline.per_question), start=1):
        d_flag = "Y" if tq["distractor"] else ""
        tree_top = tq["pages_ranked"][0] if tq["pages_ranked"] else "-"
        base_top = bq["pages_ranked"][0] if bq["pages_ranked"] else "-"
        print(f"{i:>2} {d_flag:>2} {str(tree_top):>7} {str(base_top):>7} "
              f"{tq['expected_page']:>6} {str(tq['hit1']):>6} {str(bq['hit1']):>6}")


if __name__ == "__main__":
    tree_result = evaluate_tree_pipeline()
    baseline_result = evaluate_baseline_pipeline()
    print_report(tree_result, baseline_result)
