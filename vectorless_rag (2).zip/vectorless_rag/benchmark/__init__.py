"""Benchmark package: sample document + baseline RAG + evaluation harness
comparing the vectorless tree pipeline against a conventional flat-chunk
vector-similarity RAG pipeline."""
