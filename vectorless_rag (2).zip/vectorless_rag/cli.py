"""
cli.py
-------
Command-line interface.

    python -m vectorless_rag.cli ingest doc1.md doc2.pdf --query "your question"
    python -m vectorless_rag.cli inspect doc1.md
"""

from __future__ import annotations

import argparse
import sys

from .pipeline import RAGPipeline


def main(argv=None):
    parser = argparse.ArgumentParser(prog="vectorless_rag",
                                      description="Vectorless AST-tree RAG pipeline")
    sub = parser.add_subparsers(dest="command", required=True)

    p_ingest = sub.add_parser("ingest", help="Ingest documents and optionally query them")
    p_ingest.add_argument("paths", nargs="+", help="Paths to .txt/.md/.docx/.pdf files")
    p_ingest.add_argument("--query", "-q", help="Question to ask after ingesting")
    p_ingest.add_argument("--top-k", type=int, default=5, help="Number of pages to rank")

    p_inspect = sub.add_parser("inspect", help="Print the AST tree index for documents")
    p_inspect.add_argument("paths", nargs="+")
    p_inspect.add_argument("--depth", type=int, default=4)

    args = parser.parse_args(argv)

    if args.command == "ingest":
        pipeline = RAGPipeline(top_k_pages=args.top_k)
        for path in args.paths:
            pipeline.add_document(path)
        pipeline.build()
        print(f"Indexed {len(args.paths)} document(s), "
              f"{pipeline.stats.total_leaves} leaf nodes, "
              f"{pipeline.stats.total_tokens} tokens.")

        if args.query:
            response = pipeline.query(args.query)
            _print_response(response)
        else:
            print("No --query given. Use --query \"...\" to ask a question.")

    elif args.command == "inspect":
        pipeline = RAGPipeline()
        for path in args.paths:
            pipeline.add_document(path)
        pipeline.build()
        print(pipeline.describe_tree(max_depth=args.depth))


def _print_response(response):
    print("\n=== ANSWER ===")
    print(response.answer_summary)
    print("\n=== TOP RANKED PAGES ===")
    for rp in response.ranked_pages:
        print(f"#{rp.rank} score={rp.score:<8} page={rp.node.page_start} "
              f"doc={rp.node.source} matched={rp.matched_terms}")
    print("\n=== CONTEXT SNIPPETS ===")
    for c in response.context:
        print(f"- (p.{c.page}, {c.section_title}, score={c.score:.3f}) {c.text}")


if __name__ == "__main__":
    sys.exit(main())
