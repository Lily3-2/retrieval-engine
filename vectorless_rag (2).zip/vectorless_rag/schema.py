"""
schema.py
---------
Core data structures shared by every stage of the pipeline.

Two layers of schema exist on purpose:

* RAW schema (Block / RawPage / RawDocument)
    The standardised, parser-agnostic representation produced by
    Document Ingestion. Every file format (txt, md, docx, pdf) is
    normalised into this shape before anything else happens.

* AST schema (Node / NodeType)
    The hierarchical tree built on top of the raw schema. This is
    what gets indexed, traversed, scored and ranked.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional
import itertools

_id_counter = itertools.count(1)


def _next_id(prefix: str) -> str:
    return f"{prefix}_{next(_id_counter)}"


# --------------------------------------------------------------------------
# RAW / INGESTION SCHEMA
# --------------------------------------------------------------------------

@dataclass
class Block:
    """A single unit of content extracted from a source document."""
    text: str
    block_type: str = "paragraph"   # "heading" | "paragraph" | "table"
    level: int = 0                  # heading level (1 = H1, 2 = H2, ...). 0 = not a heading.
    page: int = 1                   # 1-indexed page number this block belongs to


@dataclass
class RawPage:
    page_num: int
    blocks: List[Block] = field(default_factory=list)


@dataclass
class RawDocument:
    source: str                     # file path / doc name
    doc_id: str = field(default_factory=lambda: _next_id("doc"))
    pages: List[RawPage] = field(default_factory=list)

    @property
    def total_pages(self) -> int:
        return len(self.pages)


# --------------------------------------------------------------------------
# AST / TREE-INDEX SCHEMA
# --------------------------------------------------------------------------

class NodeType(str, Enum):
    CORPUS = "corpus"        # root over multiple documents
    DOCUMENT = "document"    # root of a single ingested document
    SECTION = "section"      # logical grouping formed by headings
    PAGE = "page"            # a physical page, nested inside a section
    PARAGRAPH = "paragraph"  # leaf-level content block


@dataclass
class Node:
    """A single node in the AST Tree Index."""
    type: NodeType
    id: str = field(default_factory=lambda: _next_id("node"))
    title: Optional[str] = None
    text: str = ""
    level: int = 0
    doc_id: Optional[str] = None
    source: Optional[str] = None
    page_start: Optional[int] = None
    page_end: Optional[int] = None
    order: int = 0                                  # deterministic sibling order
    children: List["Node"] = field(default_factory=list)
    parent: Optional["Node"] = field(default=None, repr=False)

    # populated by the indexer (index/indexer.py)
    term_freq: Dict[str, int] = field(default_factory=dict)
    token_count: int = 0

    def add_child(self, child: "Node") -> "Node":
        child.parent = self
        child.order = len(self.children)
        self.children.append(child)
        return child

    def iter_descendants(self):
        for c in self.children:
            yield c
            yield from c.iter_descendants()

    def leaves(self):
        if not self.children:
            yield self
        else:
            for c in self.children:
                yield from c.leaves()

    def path_titles(self) -> List[str]:
        """Human-readable breadcrumb from root to this node."""
        node, out = self, []
        while node is not None:
            label = node.title or f"{node.type.value}"
            if node.type == NodeType.PAGE:
                label = f"page {node.page_start}"
            out.append(label)
            node = node.parent
        return list(reversed(out))

    def __repr__(self) -> str:
        title = self.title or self.text[:30].replace("\n", " ")
        return f"<Node {self.type.value} '{title}' pages={self.page_start}-{self.page_end}>"


@dataclass
class IndexStats:
    """Corpus-level statistics required for deterministic relevance scoring."""
    doc_freq: Dict[str, int] = field(default_factory=dict)   # term -> #leaves containing it
    total_leaves: int = 0
    total_tokens: int = 0
    avg_leaf_len: float = 0.0
    idf: Dict[str, float] = field(default_factory=dict)      # term -> idf, computed lazily


@dataclass
class ContextSnippet:
    """A retrieved piece of context ready to be shown / summarised."""
    text: str
    score: float
    page: int
    section_title: str
    doc_source: str
    node_id: str


@dataclass
class RankedPage:
    node: Node
    score: float
    rank: int
    matched_terms: List[str]


@dataclass
class QueryResponse:
    query: str
    answer_summary: str
    ranked_pages: List[RankedPage]
    context: List[ContextSnippet]
