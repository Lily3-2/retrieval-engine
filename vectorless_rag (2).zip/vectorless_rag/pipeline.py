"""
pipeline.py
------------
Wires all five stages into a single, easy-to-use pipeline:

    Document Ingestion -> AST Tree Index -> Vectorless Database
    -> Page Ranking -> Query Processing & Response

Usage
-----
    from vectorless_rag.pipeline import RAGPipeline

    pipeline = RAGPipeline()
    pipeline.add_document("report.pdf")
    pipeline.add_document("notes.md")
    pipeline.build()

    response = pipeline.query("What were the key findings in Q3?")
    print(response.answer_summary)
"""

from __future__ import annotations

from typing import List, Optional

from .ingestion.parser import ingest
from .index.ast_builder import build_ast
from .index.indexer import build_index, merge_stats
from .retrieval.scorer import BM25Scorer
from .retrieval.traversal import TreeTraversal
from .retrieval.ranker import PageRanker, RankerWeights
from .query.query_processor import QueryProcessor
from .query.response_generator import ResponseGenerator, ExtractiveSummarizer, Summarizer
from .schema import IndexStats, Node, NodeType, QueryResponse


class RAGPipeline:
    def __init__(self, top_k_pages: int = 5, ranker_weights: RankerWeights = None,
                 summarizer: Summarizer = None):
        self.corpus_root = Node(type=NodeType.CORPUS, title="Corpus")
        self._doc_roots: List[Node] = []
        self._per_doc_stats: List[IndexStats] = []
        self.stats: Optional[IndexStats] = None
        self.scorer: Optional[BM25Scorer] = None

        self.top_k_pages = top_k_pages
        self.ranker_weights = ranker_weights or RankerWeights()
        self.summarizer = summarizer or ExtractiveSummarizer()

        self.query_processor = QueryProcessor()
        self.response_generator = ResponseGenerator(summarizer=self.summarizer)
        self._built = False

    # ------------------------------------------------------------------
    # Stage 1 + 2: ingest & index
    # ------------------------------------------------------------------
    def add_document(self, path: str) -> Node:
        """Ingest a single file and add it to the corpus (Stages 1 & 2)."""
        raw_doc = ingest(path)
        doc_root = build_ast(raw_doc)
        self.corpus_root.add_child(doc_root)
        self._doc_roots.append(doc_root)
        self._built = False
        return doc_root

    def build(self) -> None:
        """Finalize the index: compute term frequencies + corpus stats
        (Stages 2b/3). Must be called once after all documents are added,
        and again if more documents are added afterward."""
        per_doc_stats = []
        for doc_root in self._doc_roots:
            per_doc_stats.append(build_index(doc_root))
        self._per_doc_stats = per_doc_stats

        self.stats = merge_stats(per_doc_stats) if len(per_doc_stats) > 1 else (
            per_doc_stats[0] if per_doc_stats else IndexStats()
        )
        # re-aggregate the corpus root itself so CORPUS-level term_freq is valid
        self.corpus_root.term_freq = {}
        self.corpus_root.token_count = 0
        for doc_root in self._doc_roots:
            for term, freq in doc_root.term_freq.items():
                self.corpus_root.term_freq[term] = self.corpus_root.term_freq.get(term, 0) + freq
            self.corpus_root.token_count += doc_root.token_count

        self.scorer = BM25Scorer(self.stats)
        self._built = True

    # ------------------------------------------------------------------
    # Stage 3 + 4 + 5: retrieve, rank, respond
    # ------------------------------------------------------------------
    def query(self, query_text: str, top_k: Optional[int] = None) -> QueryResponse:
        if not self._built:
            self.build()
        if self.scorer is None or self.stats is None or self.stats.total_leaves == 0:
            return QueryResponse(query=query_text,
                                  answer_summary="The index is empty - add and build documents first.",
                                  ranked_pages=[], context=[])

        processed = self.query_processor.parse(query_text)

        traversal = TreeTraversal(self.scorer)
        result = traversal.retrieve(self.corpus_root, processed.terms)

        ranker = PageRanker(self.scorer, self.ranker_weights)
        ranked_pages = ranker.rank(result.pages, processed.terms,
                                    top_k=top_k or self.top_k_pages)

        return self.response_generator.generate(
            query=query_text,
            ranked_pages=ranked_pages,
            paragraph_candidates=result.paragraphs,
            query_terms=processed.terms,
        )

    # ------------------------------------------------------------------
    def describe_tree(self, max_depth: int = 3) -> str:
        """Debug helper: pretty-print the AST tree index."""
        lines: List[str] = []

        def walk(node: Node, depth: int):
            if depth > max_depth:
                return
            indent = "  " * depth
            label = node.title or node.type.value
            if node.type == NodeType.PAGE:
                label = f"Page {node.page_start}"
            lines.append(f"{indent}- [{node.type.value}] {label} "
                          f"(pages {node.page_start}-{node.page_end}, "
                          f"{node.token_count} tokens)")
            for child in sorted(node.children, key=lambda c: c.order):
                walk(child, depth + 1)

        walk(self.corpus_root, 0)
        return "\n".join(lines)
