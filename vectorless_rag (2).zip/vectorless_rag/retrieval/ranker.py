"""
retrieval/ranker.py
---------------------
STAGE 4: PAGE RANKING

Takes the PAGE-level candidates surfaced by the traversal stage and
produces a final ranked list, by combining the raw BM25 relevance score
with deterministic structural priors:

  * heading_boost     - a page ranks higher if the SECTION it belongs to
                         (its heading/title) also matches the query;
                         a page that's both topically AND structurally
                         relevant should outrank one that only matches
                         in passing body text.
  * position_prior    - documents often front-load key information
                         (abstracts, executive summaries, introductions);
                         a small, capped bonus rewards earlier pages so
                         ties lean toward material the author foregrounded.
  * density_bonus      - rewards pages where matched terms make up a
                         larger share of the page's own vocabulary
                         (term_freq relative to token_count), which
                         favours focused pages over long unrelated ones
                         that merely contain a stray matching word.

All factors are simple, bounded, closed-form multipliers - nothing here
is learned or stochastic, keeping the whole ranking reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from ..schema import Node, NodeType, RankedPage
from .scorer import BM25Scorer
from .traversal import Candidate


@dataclass
class RankerWeights:
    heading_boost: float = 0.35     # max extra multiplier for a section-title match
    position_prior: float = 0.10    # max extra multiplier for very early pages
    density_bonus: float = 0.25     # max extra multiplier for high match-density pages
    position_decay_pages: int = 20  # position bonus fades out by this page number

    # Opt-in guard against BM25's inherent short-document length-normalization
    # bias: a very short page that's mostly a dense keyword list (e.g. a table
    # of contents / index page enumerating many titles) can out-score the page
    # that actually answers the question, because BM25 rewards high term
    # frequency relative to document length regardless of *content type*.
    # Left at 0 by default (no behavior change) since it's a document-dependent
    # tradeoff - enable it for corpora with TOC-like or index-like pages mixed
    # in with substantive content pages. See EVALUATION_REPORT_JOB_COMPENDIUM.md
    # for a worked example of when and how much this helps.
    short_page_token_threshold: int = 0   # pages with fewer tokens than this are penalized
    short_page_penalty: float = 0.0       # fraction to reduce their multiplier by (0-1)


class PageRanker:
    def __init__(self, scorer: BM25Scorer, weights: RankerWeights = None):
        self.scorer = scorer
        self.weights = weights or RankerWeights()

    def rank(self, page_candidates: List[Candidate], query_terms: List[str],
              top_k: int = 5) -> List[RankedPage]:
        scored = []
        for cand in page_candidates:
            final_score = self._final_score(cand, query_terms)
            scored.append((final_score, cand))

        scored.sort(key=lambda pair: (pair[0], -(pair[1].node.page_start or 0)), reverse=True)

        ranked: List[RankedPage] = []
        for i, (final_score, cand) in enumerate(scored[:top_k], start=1):
            ranked.append(RankedPage(node=cand.node, score=round(final_score, 4),
                                      rank=i, matched_terms=cand.matched_terms))
        return ranked

    # ------------------------------------------------------------------
    def _final_score(self, cand: Candidate, query_terms: List[str]) -> float:
        w = self.weights
        page_node = cand.node
        base = cand.score

        section = self._parent_section(page_node)
        heading_match = 0.0
        if section is not None and section.title:
            title_overlap = self.scorer.matched_terms(section, query_terms)
            if title_overlap:
                heading_match = w.heading_boost

        page_num = page_node.page_start or 1
        position = w.position_prior * max(0.0, 1 - (page_num - 1) / w.position_decay_pages)

        density = 0.0
        if page_node.token_count:
            matched_tf = sum(page_node.term_freq.get(t, 0) for t in cand.matched_terms)
            density = w.density_bonus * min(1.0, matched_tf / page_node.token_count * 10)

        multiplier = 1.0 + heading_match + position + density
        if w.short_page_token_threshold and page_node.token_count < w.short_page_token_threshold:
            multiplier *= (1.0 - w.short_page_penalty)
        return base * multiplier

    @staticmethod
    def _parent_section(node: Node) -> Node:
        p = node.parent
        while p is not None and p.type != NodeType.SECTION:
            p = p.parent
        return p
