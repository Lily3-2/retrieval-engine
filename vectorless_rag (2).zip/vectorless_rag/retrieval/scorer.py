"""
retrieval/scorer.py
---------------------
STAGE 3: VECTORLESS DATABASE - relevance scoring

No embeddings, no nearest-neighbour search, no vector index. Relevance is
computed directly from term statistics already stored on each node
(index/indexer.py), using a BM25-style formula. Because it's a closed-form
function of (query terms, node term-freq, node token count, corpus stats),
scoring is:

  * deterministic  - the same query against the same index always returns
    the same score, byte for byte
  * explainable    - every score can be decomposed term-by-term
  * granularity-agnostic - the exact same function scores a paragraph,
    a page, a section or a whole document, since aggregation already
    happened in the indexer.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Tuple

from ..schema import IndexStats, Node


class BM25Scorer:
    """Okapi BM25 adapted to run over AST nodes instead of flat documents."""

    def __init__(self, stats: IndexStats, k1: float = 1.5, b: float = 0.75):
        self.stats = stats
        self.k1 = k1
        self.b = b

    def idf(self, term: str) -> float:
        return self.stats.idf.get(term, self._idf_for_unseen_term())

    def _idf_for_unseen_term(self) -> float:
        # A term absent from the corpus contributes a small but non-zero
        # idf so it never dominates, and never silently vanishes either.
        import math
        n = max(self.stats.total_leaves, 1)
        return math.log((n + 0.5) / 0.5 + 1.0) * 0.0  # unseen terms = 0 signal

    def score(self, node: Node, query_terms: List[str]) -> float:
        """BM25 score of `node` against `query_terms`."""
        if not query_terms or node.token_count == 0:
            return 0.0
        avgdl = self.stats.avg_leaf_len or 1.0
        dl = node.token_count
        total = 0.0
        for term in query_terms:
            tf = node.term_freq.get(term, 0)
            if tf == 0:
                continue
            idf = self.idf(term)
            numerator = tf * (self.k1 + 1)
            denominator = tf + self.k1 * (1 - self.b + self.b * dl / avgdl)
            total += idf * (numerator / denominator)
        return total

    def matched_terms(self, node: Node, query_terms: List[str]) -> List[str]:
        return [t for t in query_terms if node.term_freq.get(t, 0) > 0]

    def overlaps(self, node: Node, query_terms: List[str]) -> bool:
        """Cheap O(len(query)) overlap check used by the traversal stage
        to decide whether a subtree is worth descending into at all."""
        return any(node.term_freq.get(t, 0) > 0 for t in query_terms)
