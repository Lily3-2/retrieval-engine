"""
retrieval/traversal.py
------------------------
STAGE 3: VECTORLESS DATABASE - deterministic tree traversal

This replaces "search over a vector index" with "walk the AST". The
traversal is depth-first, visits children in stable `order`, and prunes
whole subtrees the moment they show zero term overlap with the query -
no embeddings, no ANN index, no randomness anywhere.

Because term frequencies were aggregated bottom-up at index time
(index/indexer.py), a SECTION or PAGE node's term_freq map already reflects
everything beneath it. That gives a correct, cheap pruning rule:

    if a node shares NO query terms with its own aggregated term_freq,
    none of its descendants can either -> skip the whole subtree.

Every node that survives pruning gets scored with BM25Scorer. PAGE-level
candidates are what get handed to the Page Ranking stage; PARAGRAPH-level
candidates are kept too, for fine-grained context extraction later.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from ..schema import Node, NodeType
from .scorer import BM25Scorer


@dataclass
class Candidate:
    node: Node
    score: float
    matched_terms: List[str]


@dataclass
class TraversalResult:
    pages: List[Candidate]
    paragraphs: List[Candidate]
    visited_nodes: int
    pruned_subtrees: int


class TreeTraversal:
    """Deterministic best-first-style traversal with subtree pruning."""

    def __init__(self, scorer: BM25Scorer):
        self.scorer = scorer

    def retrieve(self, root: Node, query_terms: List[str]) -> TraversalResult:
        page_candidates: List[Candidate] = []
        paragraph_candidates: List[Candidate] = []
        visited_nodes = 0
        pruned_subtrees = 0

        def walk(node: Node):
            nonlocal visited_nodes, pruned_subtrees
            visited_nodes += 1

            if node.type != NodeType.CORPUS and not self.scorer.overlaps(node, query_terms):
                pruned_subtrees += 1
                return  # prune: no descendant can match either

            score = self.scorer.score(node, query_terms)
            matched = self.scorer.matched_terms(node, query_terms)

            if node.type == NodeType.PAGE and score > 0:
                page_candidates.append(Candidate(node, score, matched))
            elif node.type == NodeType.PARAGRAPH and score > 0:
                paragraph_candidates.append(Candidate(node, score, matched))

            # deterministic order: children are visited in their stable
            # `order` field (assigned at construction time in ast_builder)
            for child in sorted(node.children, key=lambda c: c.order):
                walk(child)

        walk(root)

        page_candidates.sort(key=_sort_key, reverse=True)
        paragraph_candidates.sort(key=_sort_key, reverse=True)

        return TraversalResult(
            pages=page_candidates,
            paragraphs=paragraph_candidates,
            visited_nodes=visited_nodes,
            pruned_subtrees=pruned_subtrees,
        )


def _sort_key(c: Candidate):
    # tie-break deterministically: score desc, then earliest page, then
    # stable sibling order - never depends on hash order or randomness.
    return (c.score, -(c.node.page_start or 0), -c.node.order)
