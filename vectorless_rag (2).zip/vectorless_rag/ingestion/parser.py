"""
ingestion/parser.py
--------------------
STAGE 1: DOCUMENT INGESTION

Responsible for turning heterogeneous source files (.txt, .md, .docx, .pdf)
into the standardised `RawDocument` schema (schema.py), regardless of source
format. Downstream stages never need to know what format a document came
from.

Design notes
------------
* Headings are detected per-format (markdown '#', docx paragraph styles,
  PDF font-size / heuristics) and tagged with a `level` so the AST builder
  can reconstruct a nested section hierarchy later.
* Page granularity is preserved wherever the source format has real pages
  (PDF). For formats without native pagination (txt/md/docx) we synthesize
  pages using a deterministic heuristic (form-feed characters if present,
  otherwise a fixed character budget per page) so that "page-level" is a
  first-class, consistent concept across the whole corpus.
"""

from __future__ import annotations

import os
import re
from typing import List

from ..schema import Block, RawDocument, RawPage

# Roughly how many characters make up one synthetic "page" for formats
# that don't have native pagination. Kept small enough that ranking /
# traversal has meaningful page-level granularity even for short docs.
SYNTHETIC_PAGE_CHAR_BUDGET = 1800

MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)")


# --------------------------------------------------------------------------
# Public dispatcher
# --------------------------------------------------------------------------

def ingest(path: str) -> RawDocument:
    """Detect file type from extension and dispatch to the right parser."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".txt",):
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return parse_txt(f.read(), source=path)
    if ext in (".md", ".markdown"):
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return parse_markdown(f.read(), source=path)
    if ext == ".docx":
        return parse_docx(path)
    if ext == ".pdf":
        return parse_pdf(path)
    raise ValueError(f"Unsupported file type: {ext} ({path})")


# --------------------------------------------------------------------------
# Plain text
# --------------------------------------------------------------------------

def parse_txt(content: str, source: str = "unnamed.txt") -> RawDocument:
    """Plain text has no headings; paginate by form-feed or char budget."""
    raw_pages_text = _split_into_synthetic_pages(content)
    pages = []
    for i, page_text in enumerate(raw_pages_text, start=1):
        blocks = [
            Block(text=para.strip(), block_type="paragraph", level=0, page=i)
            for para in re.split(r"\n\s*\n", page_text)
            if para.strip()
        ]
        pages.append(RawPage(page_num=i, blocks=blocks))
    return RawDocument(source=source, pages=pages or [RawPage(page_num=1, blocks=[])])


# --------------------------------------------------------------------------
# Markdown
# --------------------------------------------------------------------------

def parse_markdown(content: str, source: str = "unnamed.md") -> RawDocument:
    """Markdown headings (#, ##, ...) become heading blocks with a level."""
    page_texts = _split_into_synthetic_pages(content, respect_form_feed=True)
    pages = []
    for i, page_text in enumerate(page_texts, start=1):
        blocks = []
        for para in re.split(r"\n\s*\n", page_text):
            para = para.strip("\n")
            if not para.strip():
                continue
            m = MD_HEADING_RE.match(para.strip())
            if m:
                level = len(m.group(1))
                blocks.append(Block(text=m.group(2).strip(), block_type="heading",
                                     level=level, page=i))
            else:
                blocks.append(Block(text=para.strip(), block_type="paragraph",
                                     level=0, page=i))
        pages.append(RawPage(page_num=i, blocks=blocks))
    return RawDocument(source=source, pages=pages or [RawPage(page_num=1, blocks=[])])


# --------------------------------------------------------------------------
# DOCX
# --------------------------------------------------------------------------

def parse_docx(path: str) -> RawDocument:
    try:
        import docx  # python-docx
    except ImportError as e:
        raise ImportError(
            "python-docx is required to parse .docx files. Install with "
            "`pip install python-docx`."
        ) from e

    document = docx.Document(path)

    blocks_flat: List[Block] = []
    char_count = 0
    page_num = 1
    pages: List[RawPage] = []
    current_blocks: List[Block] = []

    def flush_page():
        nonlocal current_blocks, page_num
        if current_blocks:
            pages.append(RawPage(page_num=page_num, blocks=current_blocks))
            current_blocks = []
            page_num += 1

    for para in document.paragraphs:
        text = para.text.strip()
        if not text:
            continue
        style = (para.style.name or "").lower()
        heading_match = re.match(r"heading\s*(\d)", style)
        # explicit manual page breaks in docx runs
        has_page_break = any(
            "w:br" in run._element.xml and 'type="page"' in run._element.xml
            for run in para.runs
        ) if hasattr(para, "runs") else False

        if heading_match:
            block = Block(text=text, block_type="heading",
                          level=int(heading_match.group(1)), page=page_num)
        elif style == "title":
            block = Block(text=text, block_type="heading", level=1, page=page_num)
        else:
            block = Block(text=text, block_type="paragraph", level=0, page=page_num)

        current_blocks.append(block)
        char_count += len(text)

        if has_page_break or char_count >= SYNTHETIC_PAGE_CHAR_BUDGET:
            flush_page()
            char_count = 0

    flush_page()
    if not pages:
        pages = [RawPage(page_num=1, blocks=[])]
    return RawDocument(source=path, pages=pages)


# --------------------------------------------------------------------------
# PDF
# --------------------------------------------------------------------------

def parse_pdf(path: str) -> RawDocument:
    try:
        from pypdf import PdfReader
    except ImportError as e:
        raise ImportError(
            "pypdf is required to parse .pdf files. Install with `pip install pypdf`."
        ) from e

    reader = PdfReader(path)
    pages: List[RawPage] = []

    for i, pdf_page in enumerate(reader.pages, start=1):
        text = pdf_page.extract_text() or ""
        blocks = []
        for line in text.split("\n"):
            line = line.strip()
            if not line:
                continue
            blocks.append(_classify_pdf_line(line, page=i))
        pages.append(RawPage(page_num=i, blocks=_merge_paragraphs(blocks)))

    return RawDocument(source=path, pages=pages or [RawPage(page_num=1, blocks=[])])


def _classify_pdf_line(line: str, page: int) -> Block:
    """Heuristic heading detection for raw PDF text extraction.

    PDF text extraction loses font-size metadata via pypdf's plain
    extractor, so we fall back to structural heuristics: short,
    title-cased or ALL-CAPS lines that don't end in sentence punctuation
    are treated as headings.
    """
    is_short = len(line) <= 80
    ends_sentence = line.endswith((".", ",", ";", ":"))
    is_upper = line.isupper() and any(c.isalpha() for c in line)
    is_title_case = line.istitle()

    if is_short and not ends_sentence and (is_upper or is_title_case):
        level = 1 if is_upper else 2
        return Block(text=line, block_type="heading", level=level, page=page)
    return Block(text=line, block_type="paragraph", level=0, page=page)


def _merge_paragraphs(blocks: List[Block]) -> List[Block]:
    """Merge consecutive plain-paragraph lines into single paragraph blocks."""
    merged: List[Block] = []
    buffer: List[str] = []

    def flush():
        if buffer:
            merged.append(Block(text=" ".join(buffer), block_type="paragraph",
                                 level=0, page=blocks[0].page if blocks else 1))
            buffer.clear()

    for b in blocks:
        if b.block_type == "heading":
            flush()
            merged.append(b)
        else:
            buffer.append(b.text)
    flush()
    return merged


# --------------------------------------------------------------------------
# Shared helpers
# --------------------------------------------------------------------------

def _split_into_synthetic_pages(content: str, respect_form_feed: bool = True) -> List[str]:
    """Split raw text into page-sized chunks.

    Priority:
      1. Explicit form-feed characters ('\\f') if present -> real page breaks.
      2. Otherwise, split on paragraph boundaries while staying under a
         fixed character budget, so pages are deterministic and stable.
    """
    if respect_form_feed and "\f" in content:
        return [p for p in content.split("\f")]

    paragraphs = re.split(r"\n\s*\n", content)
    pages: List[str] = []
    current = ""
    for para in paragraphs:
        if len(current) + len(para) > SYNTHETIC_PAGE_CHAR_BUDGET and current:
            pages.append(current)
            current = para
        else:
            current = f"{current}\n\n{para}" if current else para
    if current:
        pages.append(current)
    return pages or [content]
