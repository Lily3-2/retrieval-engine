"""
index/ast_builder.py
---------------------
STAGE 2: AST TREE INDEX WITH PAGE-LEVEL HIERARCHY

Turns a flat RawDocument (list of pages -> list of blocks) into a nested
AST:

    DOCUMENT
      SECTION ("Introduction", level 1)
        PAGE (page 1)
          PARAGRAPH
          PARAGRAPH
        PAGE (page 2)
          PARAGRAPH
        SECTION ("Background", level 2)   <- nested subsection
          PAGE (page 2)
            PARAGRAPH

Two structures are preserved simultaneously and kept consistent:

  * Logical hierarchy  -> nested SECTION nodes formed from heading levels.
  * Physical hierarchy -> PAGE nodes nested inside whichever section is
    "open" when that page's content occurs, so any node can answer both
    "what section am I in?" and "what page am I on?".

If a document has no headings at all, everything is placed under a single
implicit root SECTION so the page hierarchy still applies uniformly.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

from ..schema import Node, NodeType, RawDocument


def build_ast(raw_doc: RawDocument) -> Node:
    """Build the AST for a single ingested document."""
    root = Node(type=NodeType.DOCUMENT, title=raw_doc.source,
                doc_id=raw_doc.doc_id, source=raw_doc.source)

    # stack of (level, section_node); level 0 = implicit root section
    root_section = Node(type=NodeType.SECTION, title="Document Root", level=0,
                         doc_id=raw_doc.doc_id, source=raw_doc.source)
    root.add_child(root_section)
    section_stack: List[Tuple[int, Node]] = [(0, root_section)]

    # per-section map of page_num -> PAGE node, so content on the same
    # page within the same open section accumulates into one PAGE node.
    open_pages: Dict[int, Dict[int, Node]] = {id(root_section): {}}

    for raw_page in raw_doc.pages:
        for block in raw_page.blocks:
            if block.block_type == "heading" and block.level > 0:
                # pop back to the nearest ancestor with a strictly smaller level
                while section_stack and section_stack[-1][0] >= block.level:
                    section_stack.pop()
                parent_section = section_stack[-1][1]
                new_section = Node(type=NodeType.SECTION, title=block.text,
                                    level=block.level, doc_id=raw_doc.doc_id,
                                    source=raw_doc.source)
                parent_section.add_child(new_section)
                section_stack.append((block.level, new_section))
                open_pages[id(new_section)] = {}
                continue

            # non-heading content: attach to the PAGE node of the
            # currently open section for this page number.
            current_section = section_stack[-1][1]
            pages_for_section = open_pages.setdefault(id(current_section), {})
            page_node = pages_for_section.get(raw_page.page_num)
            if page_node is None:
                page_node = Node(type=NodeType.PAGE, page_start=raw_page.page_num,
                                  page_end=raw_page.page_num, doc_id=raw_doc.doc_id,
                                  source=raw_doc.source)
                current_section.add_child(page_node)
                pages_for_section[raw_page.page_num] = page_node

            para_node = Node(type=NodeType.PARAGRAPH, text=block.text,
                              page_start=raw_page.page_num, page_end=raw_page.page_num,
                              doc_id=raw_doc.doc_id, source=raw_doc.source)
            page_node.add_child(para_node)

    _propagate_page_ranges(root)
    return root


def _propagate_page_ranges(node: Node) -> Tuple[int, int]:
    """Post-order pass: fill in page_start/page_end for SECTION/DOCUMENT
    nodes based on the min/max page numbers of their descendants."""
    if node.type == NodeType.PARAGRAPH or node.type == NodeType.PAGE:
        return node.page_start or 1, node.page_end or 1

    starts, ends = [], []
    for child in node.children:
        s, e = _propagate_page_ranges(child)
        starts.append(s)
        ends.append(e)

    if starts:
        node.page_start, node.page_end = min(starts), max(ends)
    else:
        node.page_start, node.page_end = 1, 1
    return node.page_start, node.page_end
