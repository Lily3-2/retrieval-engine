"""
index/indexer.py
------------------
STAGE 2b / 3: builds the deterministic, non-embedding index over the AST.

Instead of encoding text into dense vectors, every node gets a plain
term-frequency map (a tiny inverted index per node). These maps are:

  * computed once at the leaf (PARAGRAPH) level from raw tokens
  * aggregated bottom-up so PAGE / SECTION / DOCUMENT / CORPUS nodes carry
    the sum of their descendants' term frequencies

This lets the same scoring function (retrieval/scorer.py) be evaluated at
ANY granularity, and gives the traversal stage cheap, honest signals for
pruning (no candidate generation via nearest-neighbour search required).

Corpus-level statistics (document frequency, idf, average leaf length) are
computed once here and reused by every query, which is what makes this a
"database" rather than a one-shot computation.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, Iterable, List

from ..schema import IndexStats, Node, NodeType

_TOKEN_RE = re.compile(r"[a-z0-9]+")

# A deliberately small, dependency-free stopword list.
STOPWORDS = frozenset("""
a an the and or but if while is are was were be been being of to in on
for with as by at from this that these those it its it's their his her
they them we you your our i he she not no nor so than then there here
do does did done can could shall should will would may might must
""".split())


def tokenize(text: str) -> List[str]:
    """Deterministic tokenizer: lowercase, strip punctuation, drop stopwords,
    then apply a light deterministic stemmer so plural/verb-form variants
    (expense/expenses, review/reviewed/reviewing) still match at query time."""
    return [_stem(t) for t in _TOKEN_RE.findall(text.lower()) if t not in STOPWORDS]


def _stem(word: str) -> str:
    """Minimal, dependency-free suffix-stripping stemmer.

    Deliberately not a full Porter stemmer - just enough deterministic
    normalisation (plurals, -ing, -ed) to close the most common vocabulary
    mismatches in a term-frequency-only (non-embedding) retrieval system,
    without pulling in NLP dependencies.
    """
    if len(word) <= 4 or not word.isalpha():
        return word
    # Longest / most specific suffixes first so e.g. "studies" -> "study".
    # Note: plain "s" (not "es") is used for simple plurals so that words
    # ending in a silent-e plural ("expense" -> "expenses") round-trip back
    # to "expense" rather than being over-stripped to "expens".
    for suffix in ("ies", "ing", "ed", "s"):
        stem_len = len(word) - len(suffix)
        if word.endswith(suffix) and stem_len >= 3:
            if suffix == "ies":
                return word[:-3] + "y"
            return word[:stem_len]
    return word


def build_index(root: Node) -> IndexStats:
    """Populate term_freq/token_count on every node in-place and return
    corpus-level statistics needed for IDF-based scoring."""
    leaves = list(root.leaves())

    doc_freq: Dict[str, int] = Counter()
    total_tokens = 0

    for leaf in leaves:
        tokens = tokenize(leaf.text)
        leaf.term_freq = Counter(tokens)
        leaf.token_count = len(tokens)
        total_tokens += leaf.token_count
        for term in leaf.term_freq:
            doc_freq[term] += 1

    stats = IndexStats(
        doc_freq=dict(doc_freq),
        total_leaves=len(leaves),
        total_tokens=total_tokens,
        avg_leaf_len=(total_tokens / len(leaves)) if leaves else 0.0,
    )
    stats.idf = _compute_idf(stats)

    _aggregate_upward(root)
    return stats


def _aggregate_upward(node: Node) -> Dict[str, int]:
    """Post-order: internal nodes' term_freq/token_count = sum of children's."""
    if not node.children:
        return node.term_freq

    agg: Counter = Counter()
    total_tokens = 0
    for child in node.children:
        child_tf = _aggregate_upward(child)
        agg.update(child_tf)
        total_tokens += child.token_count

    node.term_freq = dict(agg)
    node.token_count = total_tokens
    return node.term_freq


def _compute_idf(stats: IndexStats) -> Dict[str, float]:
    """BM25-style smoothed IDF: log((N - df + 0.5) / (df + 0.5) + 1)."""
    n = max(stats.total_leaves, 1)
    idf = {}
    for term, df in stats.doc_freq.items():
        idf[term] = math.log((n - df + 0.5) / (df + 0.5) + 1.0)
    return idf


def merge_stats(all_stats: Iterable[IndexStats]) -> IndexStats:
    """Combine per-document IndexStats into one corpus-level IndexStats
    (used when the pipeline ingests more than one document)."""
    doc_freq: Dict[str, int] = Counter()
    total_leaves = 0
    total_tokens = 0
    for s in all_stats:
        for term, df in s.doc_freq.items():
            doc_freq[term] += df
        total_leaves += s.total_leaves
        total_tokens += s.total_tokens

    merged = IndexStats(
        doc_freq=dict(doc_freq),
        total_leaves=total_leaves,
        total_tokens=total_tokens,
        avg_leaf_len=(total_tokens / total_leaves) if total_leaves else 0.0,
    )
    merged.idf = _compute_idf(merged)
    return merged
