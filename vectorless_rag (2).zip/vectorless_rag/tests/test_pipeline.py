"""
tests/test_pipeline.py
------------------------
End-to-end tests covering all five stages via the public RAGPipeline API,
plus a couple of focused unit tests for the AST builder and scorer.

Run with:  pytest -q  (from the project root's parent directory)
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from vectorless_rag.pipeline import RAGPipeline
from vectorless_rag.ingestion.parser import parse_markdown
from vectorless_rag.index.ast_builder import build_ast
from vectorless_rag.index.indexer import build_index, tokenize
from vectorless_rag.retrieval.scorer import BM25Scorer
from vectorless_rag.schema import NodeType

SAMPLE_MD = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "sample_docs", "company_handbook.md")


def _pipeline():
    p = RAGPipeline()
    p.add_document(SAMPLE_MD)
    p.build()
    return p


def test_ingestion_produces_pages_and_headings():
    with open(SAMPLE_MD, encoding="utf-8") as f:
        raw_doc = parse_markdown(f.read(), source=SAMPLE_MD)
    assert raw_doc.total_pages >= 1
    heading_blocks = [b for pg in raw_doc.pages for b in pg.blocks if b.block_type == "heading"]
    assert any(b.text == "Leave Policy" for b in heading_blocks)
    assert any(b.text == "Sick Leave" for b in heading_blocks)


def test_ast_preserves_section_and_page_hierarchy():
    with open(SAMPLE_MD, encoding="utf-8") as f:
        raw_doc = parse_markdown(f.read(), source=SAMPLE_MD)
    root = build_ast(raw_doc)

    # All H2 sections ("Leave Policy", "Remote Work Policy", ...) nest under
    # the single H1 section ("Employee Handbook"), which itself nests under
    # the implicit "Document Root" section.
    doc_root_section = root.children[0]
    h1_section = next(c for c in doc_root_section.children if c.type == NodeType.SECTION)
    assert h1_section.title == "Employee Handbook"

    section_titles = [c.title for c in h1_section.children if c.type == NodeType.SECTION]
    assert "Leave Policy" in section_titles
    assert "Remote Work Policy" in section_titles

    # "Sick Leave" (H3) should be a nested SECTION under "Leave Policy" (H2)
    leave_section = next(c for c in h1_section.children
                          if c.type == NodeType.SECTION and c.title == "Leave Policy")
    nested_titles = [c.title for c in leave_section.children if c.type == NodeType.SECTION]
    assert "Sick Leave" in nested_titles

    # and "Promotion Criteria" (H3) should nest under "Performance Reviews" (H2)
    perf_section = next(c for c in h1_section.children
                         if c.type == NodeType.SECTION and c.title == "Performance Reviews")
    perf_nested_titles = [c.title for c in perf_section.children if c.type == NodeType.SECTION]
    assert "Promotion Criteria" in perf_nested_titles

    # every SECTION/PAGE node should have a valid page range
    for node in root.iter_descendants():
        assert node.page_start is not None and node.page_end is not None
        assert node.page_start <= node.page_end


def test_indexer_builds_term_frequencies():
    with open(SAMPLE_MD, encoding="utf-8") as f:
        raw_doc = parse_markdown(f.read(), source=SAMPLE_MD)
    root = build_ast(raw_doc)
    stats = build_index(root)
    assert stats.total_leaves > 0
    assert stats.total_tokens > 0
    assert "leave" in root.term_freq  # aggregated up to the document root


def test_scorer_ranks_relevant_over_irrelevant_node():
    with open(SAMPLE_MD, encoding="utf-8") as f:
        raw_doc = parse_markdown(f.read(), source=SAMPLE_MD)
    root = build_ast(raw_doc)
    stats = build_index(root)
    scorer = BM25Scorer(stats)

    query_terms = tokenize("sick leave doctor note")
    leaves = list(root.leaves())
    sick_leaf = next(n for n in leaves if "doctor" in n.text.lower())
    unrelated_leaf = next(n for n in leaves if "expense" in n.text.lower())

    assert scorer.score(sick_leaf, query_terms) > scorer.score(unrelated_leaf, query_terms)


def test_pipeline_end_to_end_query_returns_relevant_page():
    pipeline = _pipeline()
    response = pipeline.query("How many days of sick leave do employees get?")
    assert response.ranked_pages, "expected at least one ranked page"
    assert response.context, "expected extracted context snippets"
    assert "sick" in response.answer_summary.lower() or "12" in response.answer_summary


def test_pipeline_handles_query_with_no_matches_gracefully():
    pipeline = _pipeline()
    response = pipeline.query("quantum entanglement spacecraft telemetry")
    assert response.ranked_pages == []
    assert "no sufficiently relevant" in response.answer_summary.lower()


def test_empty_pipeline_query_does_not_crash():
    pipeline = RAGPipeline()
    response = pipeline.query("anything")
    assert "empty" in response.answer_summary.lower()


if __name__ == "__main__":
    import pytest
    raise SystemExit(pytest.main([__file__, "-v"]))
