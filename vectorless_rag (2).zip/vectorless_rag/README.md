# Vectorless RAG

A retrieval-augmented generation pipeline that indexes and retrieves document
context **without embeddings or a vector database**. Relevance is computed
deterministically from term statistics stored directly on an AST-style tree
that mirrors each document's real structure (sections *and* pages).

```
Document Ingestion -> AST Tree Index -> Vectorless Database
   -> Page Ranking -> Query Processing & Response
```

## Why "vectorless"?

Instead of chunking text and embedding each chunk into a dense vector space,
this project:

1. Parses each document into a **hierarchical tree** that preserves both its
   logical structure (headings/sections) and its physical structure (pages).
2. Computes plain **term-frequency statistics** per node, aggregated bottom-up
   so any node — a paragraph, a page, a section, a whole document — can be
   scored the same way.
3. Answers a query by **walking the tree** (deterministic DFS with subtree
   pruning) and scoring nodes with a closed-form BM25-style formula — no
   nearest-neighbour search, no ANN index, no non-determinism.
4. Ranks the surviving **pages** using relevance + structural priors
   (heading match, position, match density).
5. Extracts sentence-level context from the top pages and produces a final
   answer via extractive summarization (with an optional pluggable LLM
   summarizer).

This trades some of the "fuzzy" semantic recall of embeddings for full
determinism, explainability (every score can be decomposed term-by-term),
and zero infrastructure (no vector DB, no embedding model, no GPU).

## Project layout

```
vectorless_rag/
├── schema.py                      # shared dataclasses (RawDocument, Node, IndexStats, ...)
├── pipeline.py                    # RAGPipeline: wires all 5 stages together
├── cli.py                         # command-line interface
├── example_usage.py               # runnable demo script
├── ingestion/
│   └── parser.py                  # STAGE 1: txt/md/docx/pdf -> RawDocument
├── index/
│   ├── ast_builder.py              # STAGE 2: RawDocument -> AST (sections + pages)
│   └── indexer.py                  # STAGE 2b/3: tokenize + term-freq + corpus stats
├── retrieval/
│   ├── scorer.py                   # STAGE 3: BM25-style deterministic scoring
│   ├── traversal.py                # STAGE 3: deterministic DFS + pruning
│   └── ranker.py                    # STAGE 4: page ranking (relevance + structure)
├── query/
│   ├── query_processor.py          # STAGE 5a: query parsing/tokenization
│   └── response_generator.py       # STAGE 5b: context extraction + summarization
├── sample_docs/company_handbook.md # sample document for demos/tests
└── tests/test_pipeline.py          # end-to-end + unit tests
```

## Stage-by-stage detail

### 1. Document Ingestion (`ingestion/parser.py`)
Normalises `.txt`, `.md`, `.docx`, `.pdf` into a single `RawDocument` schema:
a list of `RawPage`s, each holding ordered `Block`s tagged as `heading`
(with a level) or `paragraph`. Formats without native pagination (txt/md/docx)
get deterministic synthetic pages (form-feed characters if present, otherwise
a fixed character budget) so "page" is a consistent concept across the whole
corpus, and real PDF pages are used as-is.

### 2. AST Tree Index with Page-Level Hierarchy (`index/ast_builder.py`)
Builds a tree of `DOCUMENT -> SECTION -> PAGE -> PARAGRAPH` nodes. Headings
open new (possibly nested) `SECTION` nodes; page numbers open `PAGE` nodes
*inside whichever section is currently open*, so the tree simultaneously
encodes "what section is this in" and "what page is this on" for every
piece of content — a document with no headings still gets a uniform
page-level structure under one implicit root section.

### 3. Vectorless Database (`index/indexer.py`, `retrieval/scorer.py`, `retrieval/traversal.py`)
* `indexer.py` tokenizes every leaf paragraph, builds a term-frequency map,
  and aggregates those maps **bottom-up** so every ancestor node's
  `term_freq` reflects its entire subtree. Corpus-wide document frequency /
  IDF is computed once and reused across queries — this is the "database"
  part: a durable, queryable index, not a one-shot computation.
* `scorer.py` implements Okapi BM25 directly against a node's term-frequency
  map — fully deterministic and explainable, no learned embedding space.
* `traversal.py` walks the tree depth-first in stable order and prunes any
  subtree with zero term overlap with the query (a valid prune because
  frequencies are aggregated bottom-up), collecting scored `PAGE` and
  `PARAGRAPH` candidates as it goes.

### 4. Page Ranking (`retrieval/ranker.py`)
Combines each page's BM25 score with three bounded, deterministic priors:
* **heading boost** — does the page's enclosing section title also match?
* **position prior** — earlier pages get a small, decaying bonus (documents
  tend to front-load key information).
* **density bonus** — rewards pages where matches make up a larger share of
  the page's own vocabulary, over long pages with only incidental matches.

### 5. Query Processing & Response (`query/query_processor.py`, `query/response_generator.py`)
* `query_processor.py` tokenizes the raw query with the *same* tokenizer
  used at index time (critical — there's no learned space to bridge a
  mismatch), producing a clean, de-duplicated term list.
* `response_generator.py` pulls the best-matching sentences (not whole
  paragraphs) out of the top-ranked pages, then produces a final answer via
  a pluggable `Summarizer`:
  * `ExtractiveSummarizer` (default) — greedily selects top-scoring,
    non-duplicate sentences (Jaccard de-dup) and reorders them for
    readability. Zero external dependencies.
  * `AnthropicSummarizer` (optional) — feeds the same extracted context to
    the Claude API for a fluent abstractive answer, only if `anthropic` is
    installed and `ANTHROPIC_API_KEY` is set. The core pipeline never
    requires this.

## Installation

```bash
pip install -r requirements.txt   # only needed for docx/pdf ingestion + tests
```

The core pipeline (txt/md ingestion, indexing, retrieval, ranking, extractive
summarization) has **zero required third-party dependencies**.

## Usage

### Python API

```python
from vectorless_rag.pipeline import RAGPipeline

pipeline = RAGPipeline(top_k_pages=5)
pipeline.add_document("sample_docs/company_handbook.md")
pipeline.build()

response = pipeline.query("How many days of sick leave do employees get?")
print(response.answer_summary)

for rp in response.ranked_pages:
    print(rp.rank, rp.score, rp.node.page_start, rp.matched_terms)
```

### CLI

```bash
python -m vectorless_rag.cli ingest sample_docs/company_handbook.md \
    --query "What is the remote work policy?"

python -m vectorless_rag.cli inspect sample_docs/company_handbook.md
```

### Demo script

```bash
python -m vectorless_rag.example_usage
```

### Tests

```bash
pip install pytest
pytest vectorless_rag/tests -v
```

## Using an LLM for the final answer (optional)

```python
from vectorless_rag.pipeline import RAGPipeline
from vectorless_rag.query.response_generator import AnthropicSummarizer

pipeline = RAGPipeline(summarizer=AnthropicSummarizer())
pipeline.add_document("report.pdf")
pipeline.build()
print(pipeline.query("Summarize the key risks").answer_summary)
```

(Requires `pip install anthropic` and `ANTHROPIC_API_KEY` set. Falls back
automatically to the extractive summarizer if either is missing.)

## Benchmark: vectorless tree vs. conventional vector RAG

`benchmark/` contains a head-to-head evaluation against a conventional
flat-chunk + vector-similarity RAG pipeline (the architecture most
production RAG stacks use), run on two documents:

1. A purpose-built 9-page technical manual with deliberate "distractor"
   collisions ([`EVALUATION_REPORT.md`](benchmark/EVALUATION_REPORT.md)).
   Headline: tree wins on every retrieval metric (page-hit@1 95% vs 85%;
   MRR 0.975 vs 0.875).
2. A real, user-supplied 185-page document — a job-description compendium
   with ~150 near-duplicate job titles across 10 departments
   ([`EVALUATION_REPORT_JOB_COMPENDIUM.md`](benchmark/EVALUATION_REPORT_JOB_COMPENDIUM.md)).
   This one surfaced a genuine weakness first: with default settings the
   baseline narrowly *won* (65% vs 60% hit@1), because short, dense
   table-of-contents pages were exploiting BM25's length-normalization
   bias. A ranker tuning knob (`short_page_token_threshold` /
   `short_page_penalty` on `RankerWeights`) fixes it with **zero
   regression** on document 1, taking the tree system to 95% vs 65%.

```bash
pip install numpy scikit-learn pypdf
python -m vectorless_rag.benchmark.evaluation                 # doc 1 (markdown manual)
python -m vectorless_rag.benchmark.evaluate_job_compendium     # doc 2 (real PDF, tuned weights)
python -m vectorless_rag.benchmark.compare your_doc.pdf "your question"   # any document, no ground truth needed
```

Both reports are written as an honest investigation, not a highlight reel:
each documents where the tree system won, where it lost, why, and what
was done about it.

## Extending

* **New file formats**: add a `parse_xyz()` function to `ingestion/parser.py`
  returning a `RawDocument`, and register the extension in `ingest()`.
* **Different scoring function**: swap in an alternative to `BM25Scorer` in
  `retrieval/scorer.py` — it only needs a `.score(node, query_terms)` method.
* **Different ranking priors**: tune or extend `RankerWeights` in
  `retrieval/ranker.py`.
* **Multi-document corpora**: call `pipeline.add_document()` multiple times
  before `pipeline.build()` — ranking and retrieval already operate across
  the whole corpus tree.
