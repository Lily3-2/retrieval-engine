"""
Vectorless RAG
==============

A retrieval-augmented generation system that indexes and retrieves
document context WITHOUT vector embeddings.

Pipeline stages (map directly to project modules):

  1. Document Ingestion        -> ingestion/parser.py
  2. AST Tree Index            -> index/ast_builder.py, index/indexer.py
  3. Vectorless Database       -> retrieval/scorer.py, retrieval/traversal.py
  4. Page Ranking              -> retrieval/ranker.py
  5. Query Processing/Response -> query/query_processor.py, query/response_generator.py

See README.md for the full architecture write-up.
"""

__version__ = "1.0.0"
