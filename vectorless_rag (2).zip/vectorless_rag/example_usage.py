"""
example_usage.py
------------------
Minimal end-to-end demo of the pipeline using the bundled sample document.

Run from the parent directory of `vectorless_rag/`:

    python -m vectorless_rag.example_usage
"""

import os

from .pipeline import RAGPipeline

SAMPLE_DOC = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "sample_docs", "company_handbook.md")


def main():
    pipeline = RAGPipeline(top_k_pages=3)
    pipeline.add_document(SAMPLE_DOC)
    pipeline.build()

    print("AST Tree Index:\n")
    print(pipeline.describe_tree())

    questions = [
        "How many days of sick leave do employees get?",
        "What is the remote work policy?",
        "When are promotions decided?",
    ]

    for q in questions:
        print("\n" + "=" * 70)
        print(f"QUERY: {q}")
        response = pipeline.query(q)
        print(f"\nANSWER: {response.answer_summary}")
        print("\nTop ranked pages:")
        for rp in response.ranked_pages:
            print(f"  #{rp.rank} score={rp.score} page={rp.node.page_start} "
                  f"matched_terms={rp.matched_terms}")


if __name__ == "__main__":
    main()
