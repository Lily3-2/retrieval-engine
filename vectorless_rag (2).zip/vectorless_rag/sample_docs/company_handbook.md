# Employee Handbook

Welcome to Northwind Traders. This handbook explains our policies on leave,
expenses, remote work, and performance reviews. Please read it carefully
and reach out to HR with any questions.

## Leave Policy

Full-time employees accrue 24 days of paid annual leave per year. Leave
requests must be submitted at least two weeks in advance through the HR
portal. Unused leave can be carried over up to a maximum of 10 days into
the following year.

### Sick Leave

Employees are entitled to 12 days of paid sick leave annually. A doctor's
note is required for absences longer than three consecutive days. Sick
leave does not need to be requested in advance.

## Remote Work Policy

Employees may work remotely up to three days per week with manager
approval. Fully remote arrangements require director-level sign-off and
are reviewed every six months. All remote employees must be reachable
during core hours of 10am to 4pm local time.

## Expense Reimbursement

Business expenses must be submitted within 30 days of being incurred.
Approved categories include travel, client meals, and software
subscriptions required for work. Reimbursements are processed within
two weeks of manager approval.

## Performance Reviews

Performance reviews are conducted twice a year, in March and September.
Reviews consider goal completion, peer feedback, and manager assessment.
Employees receive a written summary and a development plan after each
review cycle.

### Promotion Criteria

Promotions are considered during the September review cycle. Candidates
are evaluated on sustained performance over at least two consecutive
review periods, scope of responsibility, and readiness for the next
level as assessed by a promotion committee.
