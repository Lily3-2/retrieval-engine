"""
query/response_generator.py
------------------------------
STAGE 5b: RESPONSE GENERATION

Given ranked pages (Stage 4) and the paragraph-level candidates from the
traversal stage (Stage 3), this module:

  1. extracts the most relevant context snippets (sentence-level, not
     whole paragraphs, so the final answer stays tight and citeable)
  2. assembles a final answer summary from that context

Summarization is pluggable via the `Summarizer` ABC:

  * `ExtractiveSummarizer` (default, always available, zero dependencies)
      scores sentences by query-term overlap + a small positional prior,
      greedily selects top sentences while skipping near-duplicates
      (Jaccard similarity), then reorders by (page, position) for
      readability.

  * `AnthropicSummarizer` (optional) calls the Claude API to produce a
      fluent abstractive summary from the SAME extracted context. It is
      only used if the `anthropic` package is installed and an API key
      is available - the retrieval/ranking pipeline itself never depends
      on any external API, keeping the "vectorless database" fully
      self-contained.
"""

from __future__ import annotations

import os
import re
from abc import ABC, abstractmethod
from typing import List

from ..schema import ContextSnippet, Node, QueryResponse, RankedPage
from ..index.indexer import tokenize
from ..retrieval.traversal import Candidate

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def split_sentences(text: str) -> List[str]:
    sentences = _SENTENCE_SPLIT_RE.split(text.strip())
    return [s.strip() for s in sentences if s.strip()]


# --------------------------------------------------------------------------
# Context extraction
# --------------------------------------------------------------------------

def extract_context(ranked_pages: List[RankedPage],
                     paragraph_candidates: List[Candidate],
                     query_terms: List[str],
                     sentences_per_page: int = 2) -> List[ContextSnippet]:
    """Pick the best sentences from the best-ranked pages' paragraphs."""
    query_term_set = set(query_terms)
    snippets: List[ContextSnippet] = []

    candidates_by_page_id = {}
    for cand in paragraph_candidates:
        page_ancestor = _find_page_ancestor(cand.node)
        if page_ancestor is None:
            continue
        candidates_by_page_id.setdefault(page_ancestor.id, []).append(cand.node)

    for rp in ranked_pages:
        paragraphs = candidates_by_page_id.get(rp.node.id, [])
        scored_sentences = []
        for para in paragraphs:
            for sent in split_sentences(para.text):
                sent_tokens = set(tokenize(sent))
                overlap = len(sent_tokens & query_term_set)
                if overlap == 0:
                    continue
                scored_sentences.append((overlap, sent))

        scored_sentences.sort(key=lambda p: p[0], reverse=True)
        top_sentences = [s for _, s in scored_sentences[:sentences_per_page]]

        section_title = _find_section_title(rp.node)
        for sent in top_sentences:
            snippets.append(ContextSnippet(
                text=sent,
                score=rp.score,
                page=rp.node.page_start or 1,
                section_title=section_title,
                doc_source=rp.node.source or "unknown",
                node_id=rp.node.id,
            ))
    return snippets


def _find_page_ancestor(node: Node):
    from ..schema import NodeType
    p = node
    while p is not None and p.type != NodeType.PAGE:
        p = p.parent
    return p


def _find_section_title(page_node: Node) -> str:
    from ..schema import NodeType
    p = page_node.parent
    while p is not None:
        if p.type == NodeType.SECTION and p.title and p.title != "Document Root":
            return p.title
        p = p.parent
    return "Document"


# --------------------------------------------------------------------------
# Summarizers (pluggable)
# --------------------------------------------------------------------------

class Summarizer(ABC):
    @abstractmethod
    def summarize(self, query: str, context: List[ContextSnippet]) -> str:
        ...


class ExtractiveSummarizer(Summarizer):
    """Zero-dependency, deterministic extractive summarizer."""

    def __init__(self, max_sentences: int = 5, jaccard_dup_threshold: float = 0.7):
        self.max_sentences = max_sentences
        self.jaccard_dup_threshold = jaccard_dup_threshold

    def summarize(self, query: str, context: List[ContextSnippet]) -> str:
        if not context:
            return ("No sufficiently relevant content was found in the indexed "
                    "documents for this query.")

        query_terms = set(tokenize(query))
        ranked = sorted(context, key=lambda c: c.score, reverse=True)

        selected: List[ContextSnippet] = []
        selected_token_sets: List[set] = []

        for snippet in ranked:
            if len(selected) >= self.max_sentences:
                break
            tokens = set(tokenize(snippet.text))
            if any(_jaccard(tokens, s) >= self.jaccard_dup_threshold for s in selected_token_sets):
                continue  # skip near-duplicate content
            selected.append(snippet)
            selected_token_sets.append(tokens)

        # reorder for readability: by page, preserving original relative order
        selected.sort(key=lambda c: (c.page, -c.score))

        lines = []
        for s in selected:
            lines.append(f"{s.text.strip()} (p.{s.page}, {s.section_title})")
        return " ".join(lines)


class AnthropicSummarizer(Summarizer):
    """Optional abstractive summarizer using the Claude API.

    Only activates if `anthropic` is installed and ANTHROPIC_API_KEY is
    set. This is entirely optional sugar on top of the vectorless
    retrieval pipeline - retrieval/ranking never depends on it.
    """

    def __init__(self, model: str = "claude-sonnet-4-6", max_tokens: int = 500):
        self.model = model
        self.max_tokens = max_tokens

    def summarize(self, query: str, context: List[ContextSnippet]) -> str:
        try:
            import anthropic
        except ImportError:
            return ExtractiveSummarizer().summarize(query, context)

        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            return ExtractiveSummarizer().summarize(query, context)

        context_text = "\n".join(
            f"[p.{c.page} - {c.section_title}] {c.text}" for c in context
        )
        prompt = (
            f"Using ONLY the context below, answer the question concisely.\n\n"
            f"Question: {query}\n\nContext:\n{context_text}\n\nAnswer:"
        )
        client = anthropic.Anthropic(api_key=api_key)
        response = client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        parts = [b.text for b in response.content if getattr(b, "type", "") == "text"]
        return "\n".join(parts).strip() or ExtractiveSummarizer().summarize(query, context)


def _jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


# --------------------------------------------------------------------------
# Top-level response generator
# --------------------------------------------------------------------------

class ResponseGenerator:
    def __init__(self, summarizer: Summarizer = None, sentences_per_page: int = 2):
        self.summarizer = summarizer or ExtractiveSummarizer()
        self.sentences_per_page = sentences_per_page

    def generate(self, query: str, ranked_pages: List[RankedPage],
                 paragraph_candidates: List[Candidate], query_terms: List[str]) -> QueryResponse:
        context = extract_context(ranked_pages, paragraph_candidates, query_terms,
                                   sentences_per_page=self.sentences_per_page)
        summary = self.summarizer.summarize(query, context)
        return QueryResponse(query=query, answer_summary=summary,
                              ranked_pages=ranked_pages, context=context)
