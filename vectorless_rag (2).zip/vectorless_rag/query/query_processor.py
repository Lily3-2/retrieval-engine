"""
query/query_processor.py
--------------------------
STAGE 5a: QUERY PROCESSING

Turns a raw natural-language query into the normalised term list the
scorer/traversal/ranker stages operate on. Reuses the exact same
tokenizer as the indexer so query terms and index terms live in the same
vocabulary space (critical for a non-embedding system - there's no
learned space to fall back on, so tokenisation MUST match exactly).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from ..index.indexer import tokenize


@dataclass
class ProcessedQuery:
    raw: str
    terms: List[str] = field(default_factory=list)     # unique, order-preserved
    all_tokens: List[str] = field(default_factory=list)  # every token, with repeats


class QueryProcessor:
    def parse(self, query: str) -> ProcessedQuery:
        tokens = tokenize(query)
        seen = set()
        unique_terms = []
        for t in tokens:
            if t not in seen:
                seen.add(t)
                unique_terms.append(t)
        return ProcessedQuery(raw=query, terms=unique_terms, all_tokens=tokens)
